/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 5.7.19 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `covid19_world4` (
	`continents` varchar (60),
	`current_confirmed_count` bigint (20),
	`confirmed_count` bigint (20),
	`suspected_count` bigint (20),
	`cured_count` bigint (20),
	`dead_count` bigint (20)
); 
insert into `covid19_world4` (`continents`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('亚洲','4545793','67162674','0','61635505','981376');
insert into `covid19_world4` (`continents`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('其他','154','741','0','574','13');
insert into `covid19_world4` (`continents`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('北美洲','7202051','44652657','0','36500267','950339');
insert into `covid19_world4` (`continents`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('南美洲','829257','36368324','0','34424815','1114252');
insert into `covid19_world4` (`continents`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('大洋洲','45813','145168','4','97378','1977');
insert into `covid19_world4` (`continents`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('欧洲','24038269','53716832','0','28522205','1156358');
insert into `covid19_world4` (`continents`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('非洲','799211','7404513','0','6419024','186278');
