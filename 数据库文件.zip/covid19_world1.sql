/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 5.7.19 
*********************************************************************
*/
/*!40101 SET NAMES utf8 */;

create table `covid19_world1` (
	`date_time` varchar (60),
	`current_confirmed_count` bigint (20),
	`confirmed_count` bigint (20),
	`suspected_count` bigint (20),
	`cured_count` bigint (20),
	`dead_count` bigint (20)
); 
insert into `covid19_world1` (`date_time`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('2021-08-03','13448085','147759465','4','130986496','3324884');
insert into `covid19_world1` (`date_time`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('2021-08-13','36092804','205987253','4','165559344','4335105');
insert into `covid19_world1` (`date_time`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('2021-08-14','36493063','206729651','4','165891357','4345231');
insert into `covid19_world1` (`date_time`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('2021-08-15','36747622','207309528','4','166204829','4357077');
insert into `covid19_world1` (`date_time`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('2021-08-16','36784257','207475758','4','166331410','4360091');
insert into `covid19_world1` (`date_time`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('2021-08-17','36845498','207962143','4','166747923','4368722');
insert into `covid19_world1` (`date_time`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('2021-08-18','37436650','209143423','4','167323028','4383745');
insert into `covid19_world1` (`date_time`, `current_confirmed_count`, `confirmed_count`, `suspected_count`, `cured_count`, `dead_count`) values('2021-08-19','37460575','209450897','4','167599729','4390593');
