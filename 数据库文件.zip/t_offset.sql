INSERT INTO `t_offset`(`topic`, `partition`, `groupid`, `offset`) VALUES ('covid19_Goods', 0, 'SparkKafka', 87);
INSERT INTO `t_offset`(`topic`, `partition`, `groupid`, `offset`) VALUES ('covid19_Goods', 1, 'SparkKafka', 94);
INSERT INTO `t_offset`(`topic`, `partition`, `groupid`, `offset`) VALUES ('covid19_Goods', 2, 'SparkKafka', 92);
