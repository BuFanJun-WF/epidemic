INSERT INTO `sys_role`(`id`, `name`, `code`, `remark`, `created`, `updated`, `statu`) VALUES (3, '普通用户', 'normal', '只有基本查看功能', '2021-08-03 10:09:14', '2021-08-04 08:19:52', 1);
INSERT INTO `sys_role`(`id`, `name`, `code`, `remark`, `created`, `updated`, `statu`) VALUES (6, '超级管理员', 'admin', '系统默认最高权限，不可以编辑和任意修改', '2021-08-03 13:29:03', '2021-08-04 15:50:45', 1);
