INSERT INTO `sys_user_role`(`id`, `user_id`, `role_id`) VALUES (4, 1, 6);
INSERT INTO `sys_user_role`(`id`, `user_id`, `role_id`) VALUES (7, 1, 3);
INSERT INTO `sys_user_role`(`id`, `user_id`, `role_id`) VALUES (13, 2, 3);
