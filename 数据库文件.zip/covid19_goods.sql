INSERT INTO `covid19_goods`(`name`, `purchase`, `allocate`, `donate`, `consume`, `demand`, `inventory`) VALUES ('84消毒液/瓶', 2000, 133, 238, -44, -76, 2251);
INSERT INTO `covid19_goods`(`name`, `purchase`, `allocate`, `donate`, `consume`, `demand`, `inventory`) VALUES ('N95口罩/个', 160, 0, 50, -253, -175, -218);
INSERT INTO `covid19_goods`(`name`, `purchase`, `allocate`, `donate`, `consume`, `demand`, `inventory`) VALUES ('一次性橡胶手套/副', 57, 90, 203, 0, -126, 224);
INSERT INTO `covid19_goods`(`name`, `purchase`, `allocate`, `donate`, `consume`, `demand`, `inventory`) VALUES ('医用外科口罩/个', 132, 58, 0, -37, -97, 56);
INSERT INTO `covid19_goods`(`name`, `purchase`, `allocate`, `donate`, `consume`, `demand`, `inventory`) VALUES ('医用防护服/套', 22, 138, 54, 0, 0, 214);
INSERT INTO `covid19_goods`(`name`, `purchase`, `allocate`, `donate`, `consume`, `demand`, `inventory`) VALUES ('电子体温计/个', 113, 47, 158, 0, 0, 318);
INSERT INTO `covid19_goods`(`name`, `purchase`, `allocate`, `donate`, `consume`, `demand`, `inventory`) VALUES ('防护目镜/副', 179, 218, 0, 0, -15, 382);
