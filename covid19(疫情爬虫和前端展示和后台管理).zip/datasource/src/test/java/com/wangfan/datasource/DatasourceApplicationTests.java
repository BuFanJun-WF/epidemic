package com.wangfan.datasource;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatasourceApplicationTests {

    @Test
    void contextLoads() {
    }

}
