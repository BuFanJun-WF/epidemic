package com.wangfan.generator;

import com.alibaba.fastjson.JSON;
import com.wangfan.bean.MaterialBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component
public class Covid19DataGenerator {

    @Autowired
    private KafkaTemplate kafkaTemplate;

    private static final String[] GOODS_NAME = new String[]{"N95口罩/个", "医用外科口罩/个", "84消毒液/瓶", "电子体温计/个", "一次性橡胶手套/副", "防护目镜/副",  "医用防护服/套"};

    private static final String[] GOODS_FROM = new String[]{"采购", "下拨", "捐赠", "消耗","需求"};

    //@Scheduled(initialDelay = 1000, fixedDelay = 1000 * 10)
    public void generator(){
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            MaterialBean materialBean = new MaterialBean(GOODS_NAME[random.nextInt(GOODS_NAME.length)], GOODS_FROM[random.nextInt(GOODS_FROM.length)], random.nextInt(100));
            //将Bean的对象转换成一个json的字符串
            String jsonString = JSON.toJSONString(materialBean);
            kafkaTemplate.send("covid19_Goods", random.nextInt(3),jsonString);
        }
    }
}
