package com.wangfan.config;

import org.apache.kafka.clients.producer.Partitioner;
import org.apache.kafka.common.Cluster;

import java.util.Map;

public class RoundRobinPartitioner implements Partitioner {

    //根据参数按照指定的规则进行分区，返回分区编号即可
    @Override
    public int partition(String topic, Object key, byte[] keyBytes, Object value, byte[] valueBytes, Cluster cluster) {
        Integer k = (Integer)key;
        //获取分区数量
        Integer partitions = cluster.partitionCountForTopic(topic);
        int repartition = k % partitions;
        System.out.println("分区编号为:"+repartition);
        return repartition;
    }

    @Override
    public void close() {
    }

    @Override
    public void configure(Map<String,?> configs) {
    }
}
