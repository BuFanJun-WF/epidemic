package com.wangfan.crawler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.wangfan.DatasourceApplication;
import com.wangfan.bean.ChinaCovidBean;
import com.wangfan.bean.WorldCovidBean;
import com.wangfan.util.HttpUtils;
import com.wangfan.util.TimeUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Component
public class WorldDataCrawler {

    @Autowired
    private KafkaTemplate kafkaTemplate;

    //@Scheduled(initialDelay = 1000,fixedDelay = 1000*60*60*24)
    //@Scheduled(cron ="0 0 8 * * ?")
    public void testCrawler() throws InterruptedException {
        System.out.println("世界疫情开始运行");
        String dateTime = TimeUtils.format(System.currentTimeMillis(), "yyyy-MM-dd");

        //爬取页面
        String html = HttpUtils.getHtml("https://ncov.dxy.cn/ncovh5/view/pneumonia");
        //System.out.println(html);

        //解析内容 id为getListByCountryTypeService2true标签中的全球疫情数据
        Document doc = Jsoup.parse(html);
        String text = doc.select("script[id=getListByCountryTypeService2true]").toString();
        //System.out.println(text);

        //使用正则表达式获取json格式的疫情数据
        String pattern ="\\[(.*)\\]";//定义正则规则
        Pattern reg = Pattern.compile(pattern);//编译成正则对象
        Matcher matcher = reg.matcher(text);//text中进行匹配
        String jsonStr="";
        if (matcher.find()){//如果匹配
            jsonStr=matcher.group(0);
            //System.out.println(jsonStr);
        }else{
            System.out.println("no match");
        }

        //对json数据进行更进一步解析
        //将省份json数据解析为WorldDataBean
        List<WorldCovidBean> CovidBeans = JSON.parseArray(jsonStr, WorldCovidBean.class);
        for (WorldCovidBean covidBean:CovidBeans){
            //设置日期
            covidBean.setDateTime(dateTime);
            //System.out.println(covidBean);
            //获取json数据中每一天的统计数据
            String statisticsDataUrl = covidBean.getStatisticsData();
            String statisticsDataStr = HttpUtils.getHtml(statisticsDataUrl);
            //获取statisticsDataStr中的data字段的数据
            JSONObject jsonObject = JSON.parseObject(statisticsDataStr);
            String dataStr = jsonObject.getString("data");
            //System.out.println(dataStr);
            //将解析出来的每一天的数据设置回Bean中的StatisticsData字段
            covidBean.setStatisticsData(dataStr);
            //System.out.println(covidBean);
            String beanStr = JSON.toJSONString(covidBean);
            kafkaTemplate.send("covid19",covidBean.getLocationId(),beanStr);

        }

    }
}
