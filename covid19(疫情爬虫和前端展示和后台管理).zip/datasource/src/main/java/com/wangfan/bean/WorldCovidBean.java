package com.wangfan.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorldCovidBean {
    private String continents;//大洲
    private String provinceName;//国家名称
    private String countryShortCode;//国家简称
    private String countryFullName;//国家全称
    private Integer locationId;//位置
    private Integer currentConfirmedCount;//当前确诊
    private Integer confirmedCount;//累计确诊
    private Integer confirmedCountRank;//累计确诊排名
    private Integer suspectedCount;//疑似病例
    private Integer curedCount;//治愈数
    private Integer deadCount;//死亡数
    private Integer deadCountRank;//死亡数排名
    private String statisticsData;//统计数据
    private String dateTime;//日期

}
