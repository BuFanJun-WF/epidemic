package com.wangfan.bean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChinaCovidBean {
    private String provinceName; //省份
    private String provinceShortName; //省份简称
    private String cityName;//城市名
    private Integer currentConfirmedCount;//当前确诊
    private Integer confirmedCount;//累计确诊
    private Integer suspectedCount;//疑似病例
    private Integer curedCount;//治愈数
    private Integer deadCount;//死亡数
    private Integer locationId;//位置id
    private Integer pid;//省份位置id
    private String statisticsData;//统计数据
    private String cities;//城市
    private String dateTime;//日期


}
