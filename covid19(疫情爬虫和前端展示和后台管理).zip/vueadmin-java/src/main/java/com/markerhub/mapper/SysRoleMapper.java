package com.markerhub.mapper;

import com.markerhub.entity.SysRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author bufanjun
 */
public interface SysRoleMapper extends BaseMapper<SysRole> {

}
