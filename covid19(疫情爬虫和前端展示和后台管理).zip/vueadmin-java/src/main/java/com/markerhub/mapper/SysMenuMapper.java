package com.markerhub.mapper;

import com.markerhub.entity.SysMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author bufanjun
 */
public interface SysMenuMapper extends BaseMapper<SysMenu> {

}
