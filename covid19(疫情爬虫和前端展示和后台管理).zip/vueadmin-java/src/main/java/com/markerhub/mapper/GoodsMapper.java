package com.markerhub.mapper;

import com.markerhub.entity.Goods;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface GoodsMapper {
    @Select({"<script> " +
            "select * from covid19_goods " +
            "where  1=1 " +
            "<if test='name!=null'> and name = #{name}</if> " +
            "</script>"})
    List<Goods> list(String name);

    @Insert("insert into covid19_goods value(#{name},#{purchase},#{allocate},#{donate},#{consume},#{demand},#{inventory})" )
    void add(String name, int purchase, int allocate,int donate, int consume, int demand, int inventory);

    @Update("update covid19_goods set purchase=#{purchase},allocate=#{allocate},donate=#{donate},consume=#{consume},demand=#{demand},inventory=#{inventory} where name=#{name}")
    void update(String name, int purchase, int allocate,int donate, int consume, int demand, int inventory);

    @Delete("delete from covid19_goods where name = #{name}")
    void  delete(String name);
}
