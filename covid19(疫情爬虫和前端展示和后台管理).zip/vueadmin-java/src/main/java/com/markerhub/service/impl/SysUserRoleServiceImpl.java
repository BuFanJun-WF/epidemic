package com.markerhub.service.impl;

import com.markerhub.entity.SysUserRole;
import com.markerhub.mapper.SysUserRoleMapper;
import com.markerhub.service.SysUserRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author 我的公众号：MarkerHub
 * @since 2021-04-05
 */
@Service
public class SysUserRoleServiceImpl extends ServiceImpl<SysUserRoleMapper, SysUserRole> implements SysUserRoleService {
    @Autowired
    SysUserRoleMapper sysUserRoleMapper;
    @Override
    public void add(long uid) {
        SysUserRole sysUserRole = new SysUserRole();
        sysUserRole.setUserId(uid);;
        sysUserRole.setRoleId(3L);
        sysUserRoleMapper.insert(sysUserRole);
    }
}
