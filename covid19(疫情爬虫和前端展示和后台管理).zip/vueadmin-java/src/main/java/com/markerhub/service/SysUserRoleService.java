package com.markerhub.service;

import com.markerhub.entity.SysUserRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author 我的公众号：MarkerHub
 * @since 2021-04-05
 */
public interface SysUserRoleService extends IService<SysUserRole> {
    void add(long uid);
}
