package com.markerhub.service.impl;

import com.markerhub.entity.Goods;
import com.markerhub.mapper.GoodsMapper;
import com.markerhub.service.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    GoodsMapper goodsMapper;

    @Override
    public List<Goods> list(String name) {
        return goodsMapper.list(name);
    }

    @Override
    public void add(String name, int purchase, int allocate, int donate, int consume, int demand, int inventory) {
        goodsMapper.add(name,purchase,allocate,donate,consume,demand,inventory);
    }

    @Override
    public void update(String name, int purchase, int allocate, int donate, int consume, int demand, int inventory) {
        goodsMapper.update(name,purchase,allocate,donate,consume,demand,inventory);
    }

    @Override
    public void delete(String name) {
        goodsMapper.delete(name);
    }
}
