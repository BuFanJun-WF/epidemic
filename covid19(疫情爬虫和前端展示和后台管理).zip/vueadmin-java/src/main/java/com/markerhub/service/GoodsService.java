package com.markerhub.service;

import com.markerhub.entity.Goods;

import java.util.List;

public interface GoodsService {
    List<Goods> list(String name);

    void add(String name, int purchase, int allocate,int donate, int consume, int demand, int inventory);

    void update(String name, int purchase, int allocate,int donate, int consume, int demand, int inventory);

    void  delete(String name);
}
