package com.markerhub.controller;

import cn.hutool.core.lang.UUID;
import cn.hutool.core.map.MapUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.google.code.kaptcha.Producer;
import com.markerhub.common.lang.Const;
import com.markerhub.common.lang.Result;
import com.markerhub.entity.Goods;
import com.markerhub.entity.SysUser;
import com.markerhub.service.GoodsService;
import com.markerhub.service.SysUserService;
import javafx.beans.binding.ObjectExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import sun.misc.BASE64Encoder;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author bufanjun
 * @Desc 通过控制器提供生成验证码
 */
@RestController
public class AuthController extends BaseController{

	@Autowired
	Producer producer;

	@Autowired
	GoodsService goodsService;

	@Autowired
	BCryptPasswordEncoder passwordEncoder;

	@GetMapping("/captcha")
	public Result captcha() throws IOException {

		String key = UUID.randomUUID().toString();
		String code = producer.createText();


		BufferedImage image = producer.createImage(code);
		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
		ImageIO.write(image, "jpg", outputStream);

		BASE64Encoder encoder = new BASE64Encoder();
		String str = "data:image/jpeg;base64,";

		String base64Img = str + encoder.encode(outputStream.toByteArray());

		redisUtil.hset(Const.CAPTCHA_KEY, key, code, 120);

		return Result.succ(
				MapUtil.builder()
						.put("token", key)
						.put("captchaImg", base64Img)
						.build()
		);
	}

	/**
	 * 获取用户信息接口
	 * @param principal
	 * @return
	 */
	@GetMapping("/sys/userInfo")
	public Result userInfo(Principal principal) {

		SysUser sysUser = sysUserService.getByUsername(principal.getName());

		return Result.succ(MapUtil.builder()
				.put("id", sysUser.getId())
				.put("username", sysUser.getUsername())
				.put("avatar", sysUser.getAvatar())
				.put("created", sysUser.getCreated())
				.map()
		);
	}

	private Object validate(SysUser sysUser) {
		if (sysUser.getUsername() == null || sysUser.getPassword() == null) {
			return "参数有误";
		}
		if (StringUtils.isEmpty(sysUser.getPassword()) || StringUtils.isEmpty(sysUser.getUsername())) {
			return "参数有误";
		}

		return null;
	}

	@PostMapping("/register")
	public Result register(@RequestBody SysUser sysUser) {

		Object error = validate(sysUser);
		if (error != null) {
			return Result.fail("参数有误");
		}
		String username = sysUser.getUsername();
		sysUser.setPassword(passwordEncoder.encode(sysUser.getPassword()));
		sysUser.setUpdated(LocalDateTime.now());
		sysUser.setStatu(1);
		sysUserService.updateById(sysUser);
		sysUserService.addUser(sysUser);
		long id = sysUserService.getByUsername(username).getId();
		sysUserRoleService.add(id);
		return Result.succ("ok");
	}

	@GetMapping("/getNum")
	public Object getNum(){
		List<Goods> list = goodsService.list(null);
		int userNum = sysUserService.page(getPage(), new QueryWrapper<SysUser>()
				.like(StrUtil.isNotBlank(null), "username", null)).getRecords().size();
		Map<String, Integer> map = new HashMap<>();
		for(Goods goods : list){
			if("医用外科口罩/个".equals(goods.getName())){
               map.put("maskNum",goods.getInventory());
			}else if("N95口罩/个".equals(goods.getName())){
				map.put("mask2Num",goods.getInventory());
			}else if("一次性橡胶手套/副".equals(goods.getName())){
				map.put("glovesNum",goods.getInventory());
			}
			else if("防护目镜/副".equals(goods.getName())){
				map.put("glassesNum",goods.getInventory());
			}
			else if("医用防护服/套".equals(goods.getName())){
				map.put("clothNum",goods.getInventory());
			}
			else if("电子体温计/个".equals(goods.getName())){
				map.put("therNum",goods.getInventory());
			}
			else if("84消毒液/瓶".equals(goods.getName())){
				map.put("lNum",goods.getInventory());
			}
		}
		map.put("userNum",userNum);
		return Result.succ(map);
	}



}
