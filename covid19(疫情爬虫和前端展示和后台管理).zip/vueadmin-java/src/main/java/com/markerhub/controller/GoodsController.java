package com.markerhub.controller;

import com.markerhub.common.lang.Result;
import com.markerhub.entity.Goods;
import com.markerhub.service.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GoodsController {

    @Autowired
    GoodsService goodsService;

    @GetMapping("/goods/list")
    public Object list(String name){
        System.out.println("----------------------"+name);
        if(StringUtils.isEmpty(name)){
            name = null;
        }
     return Result.succ(goodsService.list(name));
    }

    @PostMapping("/goods/add")
    public Object add(@RequestBody Goods goods){
        goodsService.add(goods.getName(),goods.getPurchase(),goods.getAllocate(),goods.getDonate(),goods.getConsume(),goods.getDemand(),goods.getInventory());
        return Result.succ("ok");
    }

    @PostMapping("/goods/update")
    public Object update(@RequestBody Goods goods){
        goodsService.update(goods.getName(),goods.getPurchase(),goods.getAllocate(),goods.getDonate(),goods.getConsume(),goods.getDemand(),goods.getInventory());
        return Result.succ("ok");
    }

    @GetMapping("/goods/delete")
    public Object delete(String name){
        System.out.println("delete------------"+name);
        goodsService.delete(name);
        return Result.succ("ok");
    }
}
