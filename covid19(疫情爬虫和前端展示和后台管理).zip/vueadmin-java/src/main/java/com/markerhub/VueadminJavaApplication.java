package com.markerhub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VueadminJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(VueadminJavaApplication.class, args);
	}

}
