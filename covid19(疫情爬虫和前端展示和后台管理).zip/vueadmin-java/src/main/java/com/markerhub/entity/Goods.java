package com.markerhub.entity;

import lombok.Data;

@Data
public class Goods {
    private String name;
    private int demand;
    private int purchase;
    private int allocate;
    private int consume;
    private int donate;
    private int inventory;
}
