<template>
  <div>
    <i class="el-icon-s-promotion"></i> 
    <span>疫情数据展示平台</span>
    <span style="float:right">{{time}}</span>
  </div>
</template>

<script>
export default {
  name: "Header",
  data() {
    return {
      time: null
    };
  },
  
  methods: {
    getTime() {
      let myDate = new Date();
      let myYear = myDate.getFullYear();
      let myMonth = myDate.getMonth() + 1;
      let myToday = myDate.getDate();
      let myDay = myDate.getDay();
      let myHour = myDate.getHours();
      let myMinute = myDate.getMinutes();
      let mySecond = myDate.getSeconds();
      let week = [
        "星期日",
        "星期一",
        "星期二",
        "星期三",
        "星期四",
        "星期五",
        "星期六",
      ];
      let nowTime =
        myYear +
        "-" +
        this.fillZero(myMonth) +
        "-" +
        this.fillZero(myToday) +
        "  " +
        week[myDay] +
        "  " +
        this.fillZero(myHour) +
        ":" +
        this.fillZero(myMinute) +
        ":" +
        this.fillZero(mySecond);
      // console.log(nowTime)
      this.time = nowTime
    },
    fillZero(str) {
      let realNum;
      if (str < 10) {
        realNum = "0" + str;
      } else {
        realNum = str;
      }
      return realNum;
    },
  },
  mounted() {
    this.time = setInterval(this.getTime, 1000)
  },
  beforeDestroy() {
    clearInterval(this.time)
  }
};
</script>