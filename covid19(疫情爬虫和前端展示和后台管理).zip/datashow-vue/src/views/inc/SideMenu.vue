<template>
  <div>
    <el-menu
      default-active="3"
      class="el-menu-vertical-demo"
      background-color="#545c64"
      text-color="#fff"
      active-text-color="#ffd04b"
    >
      <router-link to="/index">
        <el-menu-item index="1">
          <template slot="title">
            <i class="el-icon-s-home"></i>
            <span>首页</span>
          </template>
        </el-menu-item>
      </router-link>

      <el-submenu index="2">
        <template slot="title">
          <i class="el-icon-s-help"></i>
          <span>国内疫情数据</span>
        </template>
        <router-link to="/China/ChinaData">
          <el-menu-item index="2-1">
            <i class="el-icon-s-cooperation"></i>
            <template slot="title">全国疫情情况</template>
          </el-menu-item>
        </router-link>
        <router-link to="/China/ChinaDataTrend">
          <el-menu-item index="2-2">
            <i class="el-icon-s-order"></i>
            <template slot="title">全国疫情趋势</template>
          </el-menu-item>
        </router-link>
        <router-link to="/China/ImportChina">
          <el-menu-item index="2-3">
            <i class="el-icon-s-order"></i>
            <template slot="title">境外输入情况</template>
          </el-menu-item>
        </router-link>
      </el-submenu>

      <el-submenu index="3">
        <template slot="title">
          <i class="el-icon-s-help"></i>
          <span>省份疫情数据</span>
        </template>
        <router-link to="/Province/provinceData">
          <el-menu-item index="3-1">
            <i class="el-icon-s-cooperation"></i>
            <template slot="title">省份统计数据</template>
          </el-menu-item>
        </router-link>

        <router-link to="/Province/provinceCompare">
          <el-menu-item index="3-2">
            <i class="el-icon-s-order"></i>
            <template slot="title">省份确诊数据比较</template>
          </el-menu-item>
        </router-link>

        <router-link to="/Province/BeijingMap">
          <el-menu-item index="3-3">
            <i class="el-icon-s-order"></i>
            <template slot="title">北京疫情地图</template>
          </el-menu-item>
        </router-link>
      </el-submenu>

      <el-submenu index="4">
        <template slot="title">
          <i class="el-icon-s-help"></i>
          <span>世界疫情数据</span>
        </template>
        <router-link to="/World/WorldData">
          <el-menu-item index="4-1">
            <i class="el-icon-s-cooperation"></i>
            <template slot="title">世界疫情统计数据</template>
          </el-menu-item>
        </router-link>

        <router-link to="/World/NowData">
          <el-menu-item index="4-2">
            <i class="el-icon-s-order"></i>
            <template slot="title">世界疫情当天数据</template>
          </el-menu-item>
        </router-link>

        <router-link to="/World/WorldDataTrend">
          <el-menu-item index="4-3">
            <i class="el-icon-s-order"></i>
            <template slot="title">世界疫情趋势</template>
          </el-menu-item>
        </router-link>

        <router-link to="/World/ShowNationData">
          <el-menu-item index="4-4">
            <i class="el-icon-s-order"></i>
            <template slot="title">各国数据展示</template>
          </el-menu-item>
        </router-link>
      </el-submenu>

      <el-submenu index="5">
        <template slot="title">
          <i class="el-icon-s-help"></i>
          <span>国内人口迁徙数据</span>
        </template>
        <router-link to="/China/Population">
          <el-menu-item index="5-1">
            <i class="el-icon-s-cooperation"></i>
            <template slot="title">城市人口迁移数据</template>
          </el-menu-item>
        </router-link>
      </el-submenu>

      <router-link to="/China/Goods">
        <el-menu-item index="6">
          <template slot="title">
            <i class="el-icon-s-home"></i>
            <span>防疫物质数据展示</span>
          </template>
        </el-menu-item>
      </router-link>

      <el-menu-item index="7">
        <template slot="title">
          <i class="el-icon-s-custom"></i>
          <a
            href="http://localhost:8081/"
            style="color: white; text-decoration: none"
            >后台管理</a
          >
        </template>
      </el-menu-item>
    </el-menu>
  </div>
</template>

<script>
export default {
  name: "SideMenu",
  data() {
    return {};
  },
  methods: {},
};
</script>

<style scoped>
.el-menu-vertical-demo {
  height: 100%;
  border: none;
}
.el-menu.el-menu--horizontal {
  border: none;
}
a:link {
  text-decoration: none;
  color: white;
}
a:active {
  text-decoration: none;
  color: white;
}
a:hover {
  text-decoration: none;
  color: white;
}
a:visited {
  text-decoration: none;
  color: white;
}
</style>
