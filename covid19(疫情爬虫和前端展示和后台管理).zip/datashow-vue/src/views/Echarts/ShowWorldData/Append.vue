<template>
  <el-row :gutter="20">
    <el-col :span="24">
      <div
        class="grid-content .bg-purple"
        ref="chart"
        style="width: 100%; height: 700px"
      ></div>
    </el-col>
  </el-row>
</template>

<script>
const echarts = require("echarts");

export default {
  name: "ShowNationData",
  data() {
    return {
      date: "2021-08-03",
      chart: null,
      fiveProvince: null,
    };
  },
  created() {
    this.getTime();
    console.log("ShowNationData_created");
  },
  methods: {
    initCharts() {
      this.chart = echarts.init(this.$refs.chart);
      this.$axios
        .post("World/getWorldInTen", { time: this.date })
        .then((res) => {
          this.fiveProvince = res.data.data;
          this.chart.setOption({
            title: { text: "各国确诊病例数据前十" },
            tooltip: { trigger: "axis", axisPointer: { type: "shadow" } },
            legend: {
              data: [this.date],
            },
            grid: {
              left: "3%",
              right: "4%",
              bottom: "3%",
              containLabel: true,
            },
            xAxis: {
              type: "value",
              boundaryGap: [0, 0.01],
            },
            yAxis: {
              type: "category",
              data: [
                this.fiveProvince[9].provinceName,
                this.fiveProvince[8].provinceName,
                this.fiveProvince[7].provinceName,
                this.fiveProvince[6].provinceName,
                this.fiveProvince[5].provinceName,
                this.fiveProvince[4].provinceName,
                this.fiveProvince[3].provinceName,
                this.fiveProvince[2].provinceName,
                this.fiveProvince[1].provinceName,
                this.fiveProvince[0].provinceName,
              ],
            },
            series: [
              {
                name: this.date,
                type: "bar",
                data: [
                  this.fiveProvince[9].confirmedCount,
                  this.fiveProvince[8].confirmedCount,
                  this.fiveProvince[7].confirmedCount,
                  this.fiveProvince[6].confirmedCount,
                  this.fiveProvince[5].confirmedCount,
                  this.fiveProvince[4].confirmedCount,
                  this.fiveProvince[3].confirmedCount,
                  this.fiveProvince[2].confirmedCount,
                  this.fiveProvince[1].confirmedCount,
                  this.fiveProvince[0].confirmedCount,
                ],
              },
            ],
          });
        });
    },
    // 获取当天时间
    getTime() {
      let myDate = new Date();
      let myYear = myDate.getFullYear();
      let myMonth = myDate.getMonth() + 1;
      let myToday = myDate.getDate();
      let nowTime =
        myYear + "-" + this.fillZero(myMonth) + "-" + this.fillZero(myToday);
      // console.log(nowTime)
      this.date = nowTime;
    },
    fillZero(str) {
      let realNum;
      if (str < 10) {
        realNum = "0" + str;
      } else {
        realNum = str;
      }
      return realNum;
    },
  },
  mounted() {
    window.addEventListener("resize", () => {
      this.chart.resize();
    });
    this.initCharts();
    console.log("ShowNationData_mounted");
  },
};
</script>
<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}
.bg-purple {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
  border-radius: 2px;
  background: #ffffff;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
</style>