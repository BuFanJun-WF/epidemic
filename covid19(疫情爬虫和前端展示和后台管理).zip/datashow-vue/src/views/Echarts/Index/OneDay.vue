<template>
  <div style="padding: 10px">
    <div style="width: 100%; height: 450px" ref="chart"></div>
  </div>
</template>
<script>
const echarts = require("echarts");

export default {
  name: "OneDay",
  props: [],
  data() {
    return {
      date: null,
      chart: null,
      covid19china1: {},
    };
  },
  created() {
    this.getTime();
    console.log("OneDay_created");
  },
  methods: {
    initCharts() {
      this.chart = echarts.init(this.$refs.chart);
      this.$axios
        .post("/China/getChinaDataByDate", { time: this.date })
        .then((res) => {
          this.covid19china1 = res.data.data;
          //   console.log(this.covid19china1);
          this.chart.setOption({
            title: {
              text: "当天疫情数据",
              left: "center",
            },
            tooltip: {
              trigger: "item",
              formatter: "{a} <br/>{b} : {c} ({d}%)",
            },
            legend: {
              left: "center",
              top: "bottom",
              data: [
                "现存确诊",
                "累计确诊",
                "疑似病例",
                "累计治愈",
                "累计死亡",
              ],
            },
            toolbox: {
              show: true,
              feature: {
                mark: { show: true },
                dataView: { show: true, readOnly: false },
                restore: { show: true },
                saveAsImage: { show: true },
              },
            },
            series: [
              {
                name: "半径模式",
                type: "pie",
                radius: [20, 140],
                center: ["50%", "50%"],
                roseType: "radius",
                itemStyle: {
                  borderRadius: 5,
                },
                label: {
                  show: false,
                },
                emphasis: {
                  label: {
                    show: true,
                  },
                },
                data: [
                  {
                    value: this.covid19china1.currentConfirmedCount,
                    name: "现存确诊",
                  },
                  {
                    value: this.covid19china1.confirmedCount,
                    name: "累计确诊",
                  },
                  {
                    value: this.covid19china1.suspectedCount,
                    name: "疑似病例",
                  },
                  { value: this.covid19china1.curedCount, name: "累计治愈" },
                  { value: this.covid19china1.deadCount, name: "累计死亡" },
                ],
              },
            ],
          });
        });
    },

    /*------获取时间范围---------*/
    getTime() {
      let myDate = new Date();
      let myYear = myDate.getFullYear();
      let myMonth = myDate.getMonth() + 1;
      let myToday = myDate.getDate();
      let nowTime =
        myYear + "-" + this.fillZero(myMonth) + "-" + this.fillZero(myToday);
      // console.log(nowTime)
      this.date = nowTime;
    },
    fillZero(str) {
      let realNum;
      if (str < 10) {
        realNum = "0" + str;
      } else {
        realNum = str;
      }
      return realNum;
    },
    /*------获取时间范围---------*/
  },

  mounted() {
    window.addEventListener("resize", () => {
      this.chart.resize();
    });
    this.initCharts();
    console.log("OneDay_mounted");
  },
};
</script>

<style scoped>
</style>