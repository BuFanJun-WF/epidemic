<template>
  <el-row>
    <el-col :span="24"
      ><div class="grid-content bg-purple-dark">
        <div
          style="width: 800px; height: 800px; margin: 50px auto"
          ref="chart"
        ></div>
      </div>
    </el-col>
  </el-row>
</template>
<script>
const echarts = require("echarts");

export default {
  name: "Suspected",
  data() {
    return {
      chart: null,
      today: null,
      beforeday: null,
      chinaTrend: null,
    };
  },
  created() {
    this.getTime();
    console.log("Suspected_created");
  },
  methods: {
    initCharts() {
      this.chart = echarts.init(this.$refs.chart);
      this.$axios
        .post("/China/getChinaTrend", {
          today: this.today,
          before: this.beforeday,
        })
        .then((res) => {
          this.chinaTrend = res.data.data;

          this.chart.setOption({
            xAxis: {
              type: "category",
              boundaryGap: false,
            },
            yAxis: {
              type: "value",
              boundaryGap: [0, "30%"],
            },
            visualMap: {
              type: "piecewise",
              show: false,
              dimension: 0,
              seriesIndex: 0,
              pieces: [
                {
                  gt: 1,
                  lt: 3,
                  color: "rgba(0, 0, 180, 0.4)",
                },
                {
                  gt: 5,
                  lt: 7,
                  color: "rgba(0, 0, 180, 0.4)",
                },
              ],
            },
            series: [
              {
                type: "line",
                smooth: 0.6,
                symbol: "none",
                lineStyle: {
                  color: "#5470C6",
                  width: 5,
                },
                markLine: {
                  symbol: ["none", "none"],
                  label: { show: false },
                  data: [
                    { xAxis: 1 },
                    { xAxis: 3 },
                    { xAxis: 5 },
                  ],
                },
                areaStyle: {},
                data: [
                  [this.chinaTrend[6].dateId, this.chinaTrend[6].confirmedIncr],
                  [this.chinaTrend[5].dateId, this.chinaTrend[5].confirmedIncr],
                  [this.chinaTrend[4].dateId, this.chinaTrend[4].confirmedIncr],
                  [this.chinaTrend[3].dateId, this.chinaTrend[3].confirmedIncr],
                  [this.chinaTrend[2].dateId, this.chinaTrend[2].confirmedIncr],
                  [this.chinaTrend[1].dateId, this.chinaTrend[1].confirmedIncr],
                  [this.chinaTrend[0].dateId, this.chinaTrend[0].confirmedIncr],
                ],
              },
            ],
          });
        });
    },

    /*------获取时间范围---------*/
    getTime() {
      let myDate = new Date();
      console.log(myDate);
      let myYear = myDate.getFullYear();
      let myMonth = myDate.getMonth() + 1;
      let myToday = myDate.getDate();
      let nowTime =
        myYear + "" + this.fillZero(myMonth) + "" + this.fillZero(myToday);
      // console.log(nowTime)
      this.today = nowTime;

      let beDate = new Date(myDate - 8 * 24 * 3600 * 1000);
      let beYear = beDate.getFullYear();
      let beMonth = beDate.getMonth() + 1;
      let beToday = beDate.getDate();
      let benowTime =
        beYear + "" + this.fillZero(beMonth) + "" + this.fillZero(beToday);
      this.beforeday = benowTime;
      console.log(benowTime);
    },
    fillZero(str) {
      let realNum;
      if (str < 10) {
        realNum = "0" + str;
      } else {
        realNum = str;
      }
      return realNum;
    },
    /*------获取时间范围---------*/
  },

  mounted() {
    window.addEventListener("resize", () => {
      this.chart.resize();
    });
    this.initCharts();
    console.log("OneDay_mounted");
  },
};
</script>

<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}

.bg-purple {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
  border-radius: 2px;
  background: #ffffff;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.block {
  background: #ffffff;
  padding: 10px 10px;
}
.demonstration {
  padding: 10px 10px;
}

.searchbutton {
  padding: auto;
  margin-left: 5px;
}
</style>