<template>
  <el-container>
    <!-- 头部区域 -->
    <el-header>
      <Header></Header>
    </el-header>
    <!-- 页面主体区域 -->
    <el-container>
      <!-- 侧边栏 -->
      <el-aside width="200px" style="border: 1px solid #333">
        <SideMenu></SideMenu>
      </el-aside>
      <!-- 右侧主体内容 -->
      <el-main>
        <div style="margin: 0 15px">
          <router-view></router-view>
        </div>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
import Header from "./inc/Header.vue";
import SideMenu from "./inc/SideMenu.vue";

// 组件相关的data数据，methods方法等，都定义在export default所导出的对象
export default {
  // 对外的指明的名称，就是给别的组件import的时候的标签名
  name: "Home",
  // 对导入的组件进行注册
  components: {
    Header,
    SideMenu,
  },
  // 自定义属性，方便外部传进来参数，只能读不能写
  props: [],
  // 组件中的data不能指向对象，组件中的data必须是一个函数
  // 组件的私有化数据，data可读可写
  data() {
    // return出去的{}中，才能定义数据，也就是返回到自己的组件中，可以被拿到
    return {};
  },
  // 定义方法
  methods: {
    // 方法名，在组件中this就是表示当前组件的实例对象
  },
};
</script>

<style>
.el-container {
  padding: 0;
  margin: 0;
  height: 100%;
}
.header-avatar {
  float: right;
  width: 200px;
  display: flex;
  justify-content: space-around;
  align-items: center;
}

.el-dropdown-link {
  cursor: pointer;
}

.el-header {
  background-color: #484b4a;
  color: rgb(255, 254, 254);
  /* text-align: center; */
  line-height: 60px;
  padding: 0 10px;
}

.el-aside {
  background-color: #545c64;
  color: #333;
}

.el-main {
  color: #333;
  background-color: #f2f2f2;
  padding: 0;
}
</style>
