<template>
  <el-row :gutter="20">
    <el-col :span="24">
      <div
        class="grid-content .bg-purple"
        ref="chart"
        style="width: 100%; height: 700px"
      ></div>
    </el-col>
  </el-row>
</template>

<script>
const echarts = require("echarts");

export default {
  name: "Goods",
  data() {
    return {
      chart: null,
      GoodsList: null,
    };
  },
  created() {
    // this.getTime();
    console.log("ShowNationData_created");
  },
  methods: {
    initCharts() {
      this.chart = echarts.init(this.$refs.chart);
      this.$axios.get("China/getGoods").then((res) => {
        this.GoodsList = res.data.data;

        var xAxisData = [];
        var data1 = [];
        var data2 = [];
        var data3 = [];
        var data4 = [];
        var data5 = [];
        var data6 = [];
        var emphasisStyle = {
          itemStyle: {
            shadowBlur: 10,
            shadowColor: "rgba(0,0,0,0.3)",
          },
        };
        for (var i = 0; i < 7; i++) {
          xAxisData.push(this.GoodsList[i].name);
          data1.push(this.GoodsList[i].purchase);
          data2.push(this.GoodsList[i].allocate);
          data3.push(this.GoodsList[i].donate);
          data4.push(this.GoodsList[i].consume);
          data5.push(this.GoodsList[i].demand);
          data6.push(this.GoodsList[i].inventory);
        }

        this.chart.setOption({
          title: { text: "防疫物质" },
          legend: {
            data: ["purchase", "allocate", "donate", "consume", "demand", "inventory"],
            left: "10%",
          },
          brush: {
            toolbox: ["rect", "polygon", "lineX", "lineY", "keep", "clear"],
            xAxisIndex: 0,
          },
          toolbox: {
            feature: {
              magicType: {
                type: ["stack", "tiled"],
              },
              dataView: {},
            },
          },
          tooltip: {},
          xAxis: {
            data: xAxisData,
            name: "X Axis",
            axisLine: { onZero: true },
            splitLine: { show: false },
            splitArea: { show: false },
          },
          yAxis: {},
          grid: {
            bottom: 100,
          },
          series: [
            {
              name: "purchase",
              type: "bar",
              stack: "one",
              emphasis: emphasisStyle,
              data: data1,
            },
            {
              name: "allocate",
              type: "bar",
              stack: "one",
              emphasis: emphasisStyle,
              data: data2,
            },
            {
              name: "donate",
              type: "bar",
              stack: "two",
              emphasis: emphasisStyle,
              data: data3,
            },
            {
              name: "consume",
              type: "bar",
              stack: "two",
              emphasis: emphasisStyle,
              data: data4,
            },
            {
              name: "demand",
              type: "bar",
              stack: "two",
              emphasis: emphasisStyle,
              data: data5,
            },
            {
              name: "inventory",
              type: "bar",
              stack: "two",
              emphasis: emphasisStyle,
              data: data6,
            },
          ],
        });
      });
    },
    // 获取当天时间
    getTime() {
      let myDate = new Date();
      let myYear = myDate.getFullYear();
      let myMonth = myDate.getMonth() + 1;
      let myToday = myDate.getDate();
      let nowTime =
        myYear + "-" + this.fillZero(myMonth) + "-" + this.fillZero(myToday);
      // console.log(nowTime)
      this.date = nowTime;
    },
    fillZero(str) {
      let realNum;
      if (str < 10) {
        realNum = "0" + str;
      } else {
        realNum = str;
      }
      return realNum;
    },
  },
  mounted() {
    window.addEventListener("resize", () => {
      this.chart.resize();
    });
    this.initCharts();
    console.log("ShowNationData_mounted");
  },
};
</script>
<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}
.bg-purple {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
  border-radius: 2px;
  background: #ffffff;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
</style>