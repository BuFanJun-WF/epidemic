<template>
  <el-row :gutter="20">
    <el-col :span="24">
      <div
        class="grid-content .bg-purple"
        ref="chart"
        style="width: 100%; height: 700px"
      ></div>
    </el-col>
  </el-row>
</template>
<script>
const echarts = require("echarts");

export default {
  name: "ImportChina",
  data() {
    return {
      date: null,
      chart: null,
      fiveProvince: null,
    };
  },
  created() {
    this.getTime();
    console.log("ImportChina_created");
  },
  methods: {
    initCharts() {
      this.chart = echarts.init(this.$refs.chart);
      this.$axios
        .post("China/getImportChinaInFive", { time: this.date })
        .then((res) => {
          this.fiveProvince = res.data.data;
          this.chart.setOption({
            title: {
              text: "累计境外输入疫情",
            },
            tooltip: {
              trigger: "axis",
              axisPointer: {
                type: "shadow",
              },
            },
            legend: {
              data: [this.date],
            },
            grid: {
              left: "3%",
              right: "4%",
              bottom: "3%",
              containLabel: true,
            },
            xAxis: {
              type: "value",
              boundaryGap: [0, 0.01],
            },
            yAxis: {
              type: "category",
              data: [this.fiveProvince[0].provinceShortName,this.fiveProvince[1].provinceShortName,this.fiveProvince[2].provinceShortName,this.fiveProvince[3].provinceShortName,this.fiveProvince[4].provinceShortName,],
            },
            series: [
              {
                name: this.date,
                type: "bar",
                data: [this.fiveProvince[0].confirmedCount,this.fiveProvince[1].confirmedCount,this.fiveProvince[2].confirmedCount,this.fiveProvince[3].confirmedCount,this.fiveProvince[4].confirmedCount,],
              },
              
            ],
          });
        });
    },

    // 获取当天时间
    getTime() {
      let myDate = new Date();
      let myYear = myDate.getFullYear();
      let myMonth = myDate.getMonth() + 1;
      let myToday = myDate.getDate();
      let nowTime =
        myYear + "-" + this.fillZero(myMonth) + "-" + this.fillZero(myToday);
      // console.log(nowTime)
      this.date = nowTime;
    },
    fillZero(str) {
      let realNum;
      if (str < 10) {
        realNum = "0" + str;
      } else {
        realNum = str;
      }
      return realNum;
    },
  },

  mounted() {
    window.addEventListener("resize", () => {
      this.chart.resize();
    });
    this.initCharts();
    console.log("ImportChina_mounted");
  },
};
</script>

<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}

.bg-purple {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
  border-radius: 2px;
  background: #ffffff;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
</style>