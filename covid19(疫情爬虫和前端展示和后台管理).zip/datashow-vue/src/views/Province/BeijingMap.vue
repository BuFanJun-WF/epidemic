<template>
  <div style="padding: 10px">
    <div style="width: 100%; height: 1000px" ref="chart"></div>
  </div>
</template>
<script>
import beijing from "../../json/map/beijing"
const echarts = require("echarts");
echarts.registerMap("beijing", beijing);

export default {
  name: "BeijingMap",
  data() {
    return {
      date: null,
      chinaData: null,
      chart: null,
    };
  },
  created() {
    this.getTime();
    console.log("created");
  },
  methods: {
    initCharts() {
      this.chart = echarts.init(this.$refs.chart);
      this.$axios
        .post("China/getBeijingMapData", {
          time: this.date,
        })
        .then((res) => {
          console.log(res);
          // console.log(china);
          this.chinaData = res.data.data;
          console.log(this.chinaData);
          this.chart.setOption({
            title: {
              //标题样式
              text: "北京累计确诊人数",
              x: "center",
              textStyle: {
                fontSize: 18,
                color: "red",
              },
            },
            tooltip: {
              formatter: function (params, ticket, callback) {
                return (
                  params.seriesName +
                  "<br />" +
                  params.name +
                  "：" +
                  params.value
                );
              },
            },
            visualMap: {
              //视觉映射组件
              top: "center",
              left: "left",
              min: 0,
              max: 200,
              text: ["High", "Low"],
              realtime: false, //拖拽时，是否实时更新
              calculable: true, //是否显示拖拽用的手柄
              inRange: {
                color: ["#ffe5bf", "#ffa372", "#ff7e86", "#ee1216", "#B22222"],
              },
              show: true,
            },
            series: [
              {
                name: "累计确诊数据",
                type: "map",
                mapType: "beijing",
                roam: false, //是否开启鼠标缩放和平移漫游
                itemStyle: {
                  //地图区域的多边形 图形样式
                  normal: {
                    //是图形在默认状态下的样式
                    label: {
                      show: true, //是否显示标签
                      textStyle: {
                        color: "black",
                      },
                    },
                  },
                  zoom: 10, //地图缩放比例,默认为1
                  emphasis: {
                    //是图形在高亮状态下的样式,比如在鼠标悬浮或者图例联动高亮时
                    label: { show: true },
                  },
                },
                data: [
                  this.chinaData[1],
                  this.chinaData[2],
                  this.chinaData[3],
                  this.chinaData[4],
                  this.chinaData[5],
                  this.chinaData[6],
                  this.chinaData[7],
                  this.chinaData[8],
                  this.chinaData[9],
                  this.chinaData[10],
                  this.chinaData[11],
                  this.chinaData[12],
                  this.chinaData[13],
                  this.chinaData[14],
                  this.chinaData[15],
                  this.chinaData[16],
                  this.chinaData[17],
                  this.chinaData[18],
                  this.chinaData[19],
                ],
                top: "3%", //组件距离容器的距离
              },
            ],
          });
        });
    },

    getTime() {
      let myDate = new Date();
      let myYear = myDate.getFullYear();
      let myMonth = myDate.getMonth() + 1;
      let myToday = myDate.getDate();
      let nowTime =
        myYear + "-" + this.fillZero(myMonth) + "-" + this.fillZero(myToday);
      // console.log(nowTime)
      this.date = nowTime;
    },
    fillZero(str) {
      let realNum;
      if (str < 10) {
        realNum = "0" + str;
      } else {
        realNum = str;
      }
      return realNum;
    },
  },

  mounted() {
    window.addEventListener("resize", () => {
      this.chart.resize();
    });
    this.initCharts();
    console.log("mounted");
  },
};
</script>
