<template>
  <div class="provinceData">
    <el-row :gutter="20">
      <el-col :span="24">
        <div class="grid-content bg-purple">
          <div class="block" style="span: 10px 10px 10px 10px">
            <span class="demonstration">时间搜索范围</span>
            <el-date-picker
              @change="dateChange"
              v-model="selectDate"
              type="daterange"
              range-separator="-"
              start-placeholder="开始日期"
              end-placeholder="结束日期"
              :picker-options="pickerOptions"
            >
            </el-date-picker>

            <el-input
              v-model="searchMap.name"
              style="width: 20%"
              placeholder="请输入省份名称"
            ></el-input>

            <el-button
              class="searchbutton"
              type="primary"
              plain
              @click="
                searchMap.pageNum = 1;
                search();
              "
              >搜索</el-button
            >
          </div>
        </div>
      </el-col>
    </el-row>

    <el-row>
      <el-col :span="24"
        ><div class="grid-content bg-purple-dark">
          <el-table
            :cell-style="rowClass"
            :header-cell-style="headClass"
            ref="multipleTable"
            :data="tableData"
            tooltip-effect="dark"
            style="width: 100%"
            border
            stripe
            :default-sort="{ prop: 'dateTime', order: 'descending' }"
          >
            <el-table-column prop="dateTime" label="日期" width="120" sortable>
            </el-table-column>
            <el-table-column
              prop="locationId"
              label="省份编码"
              show-overflow-tooltip
            >
            </el-table-column>
            <el-table-column
              prop="provinceShortName"
              label="省份"
              show-overflow-tooltip
            >
            </el-table-column>
            <el-table-column
              prop="currentConfirmedCount"
              label="现存确诊"
              show-overflow-tooltip
            >
            </el-table-column>
            <el-table-column
              prop="confirmedCount"
              label="累计确诊"
              show-overflow-tooltip
              sortable
            ></el-table-column>

            <el-table-column
              prop="suspectedCount"
              label="疑似病例"
              show-overflow-tooltip
            ></el-table-column>

            <el-table-column
              prop="curedCount"
              label="累计治愈"
              show-overflow-tooltip
            ></el-table-column>

            <el-table-column
              prop="deadCount"
              label="累计死亡"
              show-overflow-tooltip
            ></el-table-column>
            <el-table-column
              prop="remark"
              label="图表展示"
              show-overflow-tooltip
            >
              <template slot-scope="scope">
                <el-button
                  type="text"
                  @click="saveRow(scope.row), (centerDialogVisible = true)"
                  >展示</el-button
                >
              </template>
            </el-table-column>
          </el-table>

          <el-dialog
            title="柱状图展示"
            :visible.sync="centerDialogVisible"
            width="40%"
            @open="open()"
            center
          >
            <div id="chart" style="width: 500px; height: 400px"></div>
            <span slot="footer" class="dialog-footer">
              <el-button @click="centerDialogVisible = false">取 消</el-button>
              <el-button type="primary" @click="centerDialogVisible = false"
                >确 定</el-button
              >
            </span>
          </el-dialog>

          <!-- 表格下面的分页栏 -->
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            layout="prev, pager, next,sizes"
            :page-sizes="[2, 10, 20, 50, 100]"
            :page-size="searchMap.pageSize"
            style="text-align: right"
            :total="total"
          >
          </el-pagination></div
      ></el-col>
    </el-row>
  </div>
</template>
<script>
const echarts = require("echarts");
export default {
  name: "ChainData",
  data() {
    return {
      rowdata: null,
      size: 10,
      current: 1,
      total: 10,
      tableData: [],
      // 查询条件
      searchMap: {
        startTime: "",
        endTime: "",
        name: "",
        pageNum: 1,
        pageSize: 10,
      },
      // 页面上搜索时间的同步
      selectDate: ["", ""],
      pickerOptions: {
        shortcuts: [
          {
            text: "最近一周",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近一个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30);
              picker.$emit("pick", [start, end]);
            },
          },
          {
            text: "最近三个月",
            onClick(picker) {
              const end = new Date();
              const start = new Date();
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90);
              picker.$emit("pick", [start, end]);
            },
          },
        ],
      },
      // 进行参考弹框
      centerDialogVisible: false,
    };
  },

  created() {
    this.search();
  },

  methods: {
    // 查询分页数据
    search() {
      this.$axios.post("/China/searchProvince", this.searchMap).then((res) => {
        this.tableData = res.data.data;
        this.total = res.data.total;
        // console.log(this.tableData);
      });
    },
    //handleSizeChange每页数量发生变化后触发的方法
    handleSizeChange(pageSize) {
      this.searchMap.pageSize = pageSize;
      this.search();
    },
    //handleCurrentChange页码变化触发方法
    handleCurrentChange(pageNum) {
      this.searchMap.pageNum = pageNum;
      this.search();
    },
    //时间区间发生改变，searcHMap中时间区间条件也要变化
    dateChange() {
      //没有选择时间区间或者清理时间条件，当前时间区间为空字符串
      if (this.selectDate == null || this.selectDate.length == 0) {
        this.searchMap.startTime = "";
        this.searchMap.endTime = "";
      } else {
        //当时间区间不为空，往searchMap中添加条件
        if (this.selectDate[0] != null && this.selectDate[0] != "") {
          this.searchMap.startTime = this.dateFormat(this.selectDate[0]);
        }
        if (this.selectDate[1] != null && this.selectDate[1] != "") {
          this.searchMap.endTime = this.dateFormat(this.selectDate[1]);
        }
      }
      console.log(this.searchMap);
    },
    //日期格式化方法
    //date 要进行格式的日期 ；format 格式化的样式
    dateFormat(date, format) {
      //默认格式化字符串"YYYY-MM-DD HH:mm:ss"
      if (format == null || format == "") {
        format = "YYYY-MM-DD";
      }
      return this.$moment(date).format(format);
    },
    rowClass() {
      //表格数据居中显示
      return "text-align:center";
    },
    headClass() {
      //表头居中显示
      return "text-align:center";
    },

    // ---------展示表格内容---------- //
    // 获取同一行的表头信息
    saveRow(row) {
      // console.log(row);
      this.rowdata = row;
      console.log(this.rowdata);
    },
    initCharts() {
      this.chart = echarts.init(document.getElementById("chart"));
      this.chart.setOption({
        tooltip: {
          trigger: "item",
        },
        legend: {
          top: "5%",
          left: "center",
        },

        series: [
          {
            name: "访问来源",
            type: "pie",
            radius: ["40%", "70%"],
            avoidLabelOverlap: false,
            label: {
              show: false,
              position: "center",
            },
            emphasis: {
              label: {
                show: true,
                fontSize: "40",
                fontWeight: "bold",
              },
            },
            labelLine: {
              show: false,
            },
            data: [
              { value: this.rowdata.currentConfirmedCount, name: "现存确诊" },
              { value: this.rowdata.confirmedCount, name: "累计确诊" },
              { value: this.rowdata.suspectedCount, name: "疑似病例" },
              { value: this.rowdata.curedCount, name: "累计治愈" },
              { value: this.rowdata.deadCount, name: "累计死亡" },
            ],
          },
        ],

      });
    },
    open() {
      window.addEventListener("resize", () => {
        this.chart.resize();
      });
      this.$nextTick(() => {
        this.initCharts();
      });

      console.log("open");
    },
  },
};
</script>


<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}

.bg-purple {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
  border-radius: 2px;
  background: #ffffff;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.block {
  background: #ffffff;
  padding: 10px 10px;
}
.demonstration {
  padding: 10px 10px;
}

.searchbutton {
  padding: auto;
  margin-left: 5px;
}

.table {
  border-top: 20px solid #f2f2f2;
  padding: 10px;
}
.el-pagination {
  float: right;
  margin-top: 22px;
}
</style>