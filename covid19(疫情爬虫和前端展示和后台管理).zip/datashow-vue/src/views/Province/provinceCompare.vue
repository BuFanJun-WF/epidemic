<template >
  <div class="procinceCompare">
    <el-row :gutter="20">
      <el-col :span="24">
        <div class="grid-content bg-purple">
          <div class="block" style="span: 10px 10px 10px 10px">
            <el-input
              v-model="searchMap.name1"
              style="width: 20%"
              placeholder="请输入省份名称"
            ></el-input>
            <span class="demonstration">VS</span>
            <el-input
              v-model="searchMap.name2"
              style="width: 20%"
              placeholder="请输入省份名称"
            ></el-input>

            <el-button
              class="searchbutton"
              type="primary"
              plain
              @click="search()"
              >搜索</el-button
            >
          </div>
        </div>
      </el-col>
    </el-row>
    <el-row :gutter="20">
      <el-col :span="24">
        <div
          style="width: 800px; height: 800px; margin: 50px auto"
          ref="chart"
        ></div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
const echarts = require("echarts");
export default {
  name: "provinceCompare",
  data() {
    return {
      showData: null,

      // 查询条件
      searchMap: {
        today: null,
        beforeday: null,
        name1: "北京",
        name2: "广东",
      },
    };
  },
  created() {
    this.getTime();
    console.log("provinceCompare_created");
  },
  methods: {
    initCharts() {
      this.chart = echarts.init(this.$refs.chart);
      var app = {};
      var posList = [
        "left",
        "right",
        "top",
        "bottom",
        "inside",
        "insideTop",
        "insideLeft",
        "insideRight",
        "insideBottom",
        "insideTopLeft",
        "insideTopRight",
        "insideBottomLeft",
        "insideBottomRight",
      ];
      app.configParameters = {
        rotate: {
          min: -90,
          max: 90,
        },
        align: {
          options: {
            left: "left",
            center: "center",
            right: "right",
          },
        },
        verticalAlign: {
          options: {
            top: "top",
            middle: "middle",
            bottom: "bottom",
          },
        },
        position: {
          options: posList.reduce(function (map, pos) {
            map[pos] = pos;
            return map;
          }, {}),
        },
        distance: {
          min: 0,
          max: 100,
        },
      };

      app.config = {
        rotate: 90,
        align: "left",
        verticalAlign: "middle",
        position: "insideBottom",
        distance: 15,
        onChange: function () {
          var labelOption = {
            normal: {
              rotate: app.config.rotate,
              align: app.config.align,
              verticalAlign: app.config.verticalAlign,
              position: app.config.position,
              distance: app.config.distance,
            },
          };
          this.chart.setOption({
            series: [
              {
                label: labelOption,
              },
              {
                label: labelOption,
              },
            ],
          });
        },
      };
      var labelOption = {
        show: true,
        position: app.config.position,
        distance: app.config.distance,
        align: app.config.align,
        verticalAlign: app.config.verticalAlign,
        rotate: app.config.rotate,
        formatter: "{c}  {name|{a}}",
        fontSize: 16,
        rich: {
          name: {},
        },
      };
      this.chart.setOption({
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },
        legend: {
          data: [this.showData[0].provinceShortName+"累计确诊", this.showData[1].provinceShortName+"累计确诊",],
        },
        toolbox: {
          show: true,
          orient: "vertical",
          left: "right",
          top: "center",
          feature: {
            mark: { show: true },
            dataView: { show: true, readOnly: false },
            magicType: { show: true, type: ["line", "bar", "stack", "tiled"] },
            restore: { show: true },
            saveAsImage: { show: true },
          },
        },
        xAxis: [
          {
            type: "category",
            axisTick: { show: false },
            data: [this.showData[0].dateTime,this.showData[2].dateTime,],
          },
        ],
        yAxis: [
          {
            type: "value",
          },
        ],
        series: [
          {
            name: this.showData[0].provinceShortName+"累计确诊",
            type: "bar",
            barGap: 0,
            label: labelOption,
            emphasis: {
              focus: "series",
            },
            data: [this.showData[0].confirmedCount, this.showData[2].confirmedCount,],
          },
          {
            name: this.showData[1].provinceShortName+"累计确诊",
            type: "bar",
            label: labelOption,
            emphasis: {
              focus: "series",
            },
            data: [this.showData[1].confirmedCount, this.showData[3].confirmedCount],
          },
        ],
      });
    },

    // 查询展示数据
    search() {
      this.$axios.post("/China/showToProvince", this.searchMap).then((res) => {
        this.showData = res.data.data;
        console.log(this.searchMap);
        console.log(this.showData);

        this.initCharts();
      });
    },
    /*------获取时间范围---------*/
    getTime() {
      let myDate = new Date();
      console.log(myDate);
      let myYear = myDate.getFullYear();
      let myMonth = myDate.getMonth() + 1;
      let myToday = myDate.getDate();
      let nowTime =
        myYear + "-" + this.fillZero(myMonth) + "-" + this.fillZero(myToday);
      // console.log(nowTime)
      this.searchMap.today = nowTime;

      let beDate = new Date(myDate - 1 * 24 * 3600 * 1000);
      let beYear = beDate.getFullYear();
      let beMonth = beDate.getMonth() + 1;
      let beToday = beDate.getDate();
      let benowTime =
        beYear + "-" + this.fillZero(beMonth) + "-" + this.fillZero(beToday);
      this.searchMap.beforeday = benowTime;
      console.log(this.searchMap.beforeday);
    },
    fillZero(str) {
      let realNum;
      if (str < 10) {
        realNum = "0" + str;
      } else {
        realNum = str;
      }
      return realNum;
    },
    /*------获取时间范围---------*/
  },
  mounted() {
    window.addEventListener("resize", () => {
      this.chart.resize();
    });
    
    console.log("OneDay_mounted");
  },
};
</script>

<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}

.bg-purple {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
  border-radius: 2px;
  background: #ffffff;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.block {
  background: #ffffff;
  padding: 10px 10px;
}
.demonstration {
  padding: 10px 10px;
}

.searchbutton {
  padding: auto;
  margin-left: 5px;
}

.table {
  border-top: 20px solid #f2f2f2;
  padding: 10px;
}
.el-pagination {
  float: right;
  margin-top: 22px;
}
</style>