<template>
  <div class="index">
    <IndexHead :date="date" :covid19china1="covid19china1"></IndexHead>
    <IndexMain></IndexMain>
    <IndexFoot></IndexFoot>
  </div>
</template>
<script>
import IndexHead from "../components/IndexHead";
import IndexMain from "../components/IndexMain";
import IndexFoot from "../components/IndexFoot";

export default {
  name: "Index",
  data() {
    return {
      date: null,
      covid19china1: {},
    };
  },
  components: {
    IndexHead,
    IndexMain,
    IndexFoot,
  },
  created() {
    this.getTime();
    this.$axios
      .post("/China/getChinaDataByDate", { time: this.date })
      .then((res) => {
        this.covid19china1 = res.data.data;
        // console.log(this.covid19china1);
      });

  },
  methods: {
    getTime() {
      let myDate = new Date();
      let myYear = myDate.getFullYear();
      let myMonth = myDate.getMonth() + 1;
      let myToday = myDate.getDate();
      let nowTime =
        myYear + "-" + this.fillZero(myMonth) + "-" + this.fillZero(myToday);
      // console.log(nowTime)
      this.date = nowTime;
    },
    fillZero(str) {
      let realNum;
      if (str < 10) {
        realNum = "0" + str;
      } else {
        realNum = str;
      }
      return realNum;
    },
  },
};
</script>

<style scoped>
.el-menu {
  border-right: solid 0px #e6e6e6;
}
</style>