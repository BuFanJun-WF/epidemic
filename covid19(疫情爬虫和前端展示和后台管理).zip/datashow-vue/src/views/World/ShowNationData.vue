<template>
  <div class="ShowNationData">
    <el-row :gutter="20">
      <el-col :span="6">
        <div class="grid-content bg-purple">
          <router-link to="/World/ShowNationData/Append">
            <el-button>世界前10个国家确诊人数排名</el-button>
          </router-link>
        </div>
      </el-col>
      <el-col :span="6">
        <div class="grid-content bg-purple">
          <router-link to="/World/ShowNationData/Cured">
            <el-button type="success">世界前10个国家治愈人数排名</el-button>
          </router-link>
        </div>
      </el-col>
      <el-col :span="6">
        <div class="grid-content bg-purple">
          <router-link to="/World/ShowNationData/Dead">
            <el-button type="danger">世界前10个国家死亡人数排名</el-button>
          </router-link>
        </div>
      </el-col>
      <el-col :span="6">
        <div class="grid-content bg-purple">
          <router-link to="/World/ShowNationData/Suspected">
            <el-button type="warning">世界前10个国家疑似人数排名</el-button>
          </router-link>
        </div>
      </el-col>
    </el-row>

    <el-row :gutter="20">
      <router-view></router-view>
    </el-row>
  </div>
</template>
<script>
export default {
  name: "ShowNationData",
  data() {
    return {
    };
  },
  methods: {},
};
</script>

<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}
</style>



