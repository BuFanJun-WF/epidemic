<template>
  <div class="WorldDataTrend">
    <el-row :gutter="20">
      <el-col :span="6">
        <div class="grid-content bg-purple">
          <router-link to="/World/WorldDataTrend/Append">
            <el-button>世界最近一星期新增确诊</el-button>
          </router-link>
        </div>
      </el-col>
      <el-col :span="6">
        <div class="grid-content bg-purple">
          <router-link to="/World/WorldDataTrend/Cured">
            <el-button type="success">世界最近一星期治愈人数趋势</el-button>
          </router-link>
        </div>
      </el-col>
      <el-col :span="6">
        <div class="grid-content bg-purple">
          <router-link to="/World/WorldDataTrend/Dead">
            <el-button type="danger">世界最近一星期死亡人数趋势</el-button>
          </router-link>
        </div>
      </el-col>
      <el-col :span="6">
        <div class="grid-content bg-purple">
          <router-link to="/World/WorldDataTrend/Suspected">
            <el-button type="warning">世界最近一星期疑似确诊人数趋势</el-button>
          </router-link>
        </div>
      </el-col>
    </el-row>

    <el-row :gutter="20">
      <router-view></router-view>
    </el-row>
  </div>
</template>
<script>
export default {
  name: "WorldDataTrend",
  data() {
    return {
    };
  },
  methods: {},
};
</script>

<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}
</style>



