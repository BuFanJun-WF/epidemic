<template>
  <div style="padding: 10px">
    <div style="width: 100%; height: 500px" ref="chart"></div>
  </div>
</template>
<script>
const echarts = require("echarts");

export default {
  name: "WorldData",
  data() {
    return {
      chart: null,
      xdata: null,
      dayList: null,
    };
  },
  created() {
    console.log("created");
  },
  methods: {
    initCharts() {
      this.chart = echarts.init(this.$refs.chart);
      this.$axios.get("World/fillAllData").then((res) => {
        console.log(res);
        this.dayList = res.data.data;
        let arr = res.data.data;
        let xdata2 = [];
        for (var i = 0; i < arr.length; i++) {
          xdata2.push(arr[i].dateId);
        }
        this.xdata = xdata2;
        console.log(xdata2);
        this.chart.setOption({
          title: {
            text: "世界疫情趋势",
          },
          tooltip: {
            trigger: "axis",
            axisPointer: {
              type: "cross",
              label: {
                backgroundColor: "#6a7985",
              },
            },
          },
          legend: {
            data: [
              "confirmedCount",
              "confirmedIncr",
              "curedCount",
              "deadCount",
              "suspectedCount",
            ],
          },
          dataset: {
            // 这里指定了维度名的顺序，从而可以利用默认的维度到坐标轴的映射。
            dimensions: [
              "dateId",
              "confirmedCount",
              "confirmedIncr",
              "curedCount",
              "deadCount",
              "suspectedCount",
            ],
            source: this.dayList,
          },

          toolbox: {
            feature: {
              saveAsImage: {},
            },
          },
          grid: {
            left: "3%",
            right: "4%",
            bottom: "3%",
            containLabel: true,
          },
          xAxis: [
            {
              type: "category",
              boundaryGap: false,
              data: this.xdata,
            },
          ],
          yAxis: [
            {
              type: "value",
            },
          ],
          series: [
            {
              type: "line",
              areaStyle: {},
              emphasis: {
                focus: "series",
              },
            },
            {
              type: "line",
              areaStyle: {},
              emphasis: {
                focus: "series",
              },
            },
            {
              type: "line",
              areaStyle: {},
              emphasis: {
                focus: "series",
              },
            },
            {
              type: "line",
              areaStyle: {},
              emphasis: {
                focus: "series",
              },
            },
            {
              type: "line",
              areaStyle: {},
              emphasis: {
                focus: "series",
              },
            },
          ],
        });
      });
    },
  },

  mounted() {
    window.addEventListener("resize", () => {
      this.chart.resize();
    });
    this.initCharts();
    console.log("mounted");
  },
};
</script>
