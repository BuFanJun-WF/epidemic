// 1.导入Vue和VueRouter的包
import Vue from 'vue'
import VueRouter from 'vue-router'

// 导入需要使用路由切换展示的组件
import Home from '../views/Home.vue'

// 2.调用Vue.use()函数，把VueRouter安装为Vue的插件
Vue.use(VueRouter)

// 在routes数组中，声明路由的匹配规则
const routes = [
  // path表示要匹配的hash地址，component表示要展示的路由组件
  {
    path: '/',
    name: 'Home',
    component: Home,
    children: [
      {
        path: '/index',
        name: 'Index',
        meta: {
          title: "首页"
        },
        component: () => import('@/views/Index.vue')
      },
      {
        path: '/China/ChinaData',
        name: 'ChinaData',
        meta: {
          title: "全国疫情情况"
        },
        component: () => import('@/views/China/ChinaData.vue')
      },
      {
        path: '/China/ChinaDataTrend',
        name: 'ChinaDataTrend',
        meta: {
          title: "全国疫情趋势"
        },
        component: () => import('@/views/China/ChinaDataTrend.vue'),
        children: [
          {
            path: '/China/ChinaDataTrend/Append',
            name: 'Append',
            meta: {
              title: "全国最近一星期新增确诊"
            },
            component: () => import('@/views/Echarts/nation/Append.vue'),
          },
          {
            path: '/China/ChinaDataTrend/Cured',
            name: 'Cured',
            meta: {
              title: "全国最近一星期治愈人数趋势"
            },
            component: () => import('@/views/Echarts/nation/Cured.vue'),
          },
          {
            path: '/China/ChinaDataTrend/Dead',
            name: 'Dead',
            meta: {
              title: "全国最近一星期死亡人数趋势"
            },
            component: () => import('@/views/Echarts/nation/Dead.vue'),
          },
          {
            path: '/China/ChinaDataTrend/Suspected',
            name: 'Suspected',
            meta: {
              title: "全国最近一星期疑似确诊人数趋势"
            },
            component: () => import('@/views/Echarts/nation/Suspected.vue'),
          },
        ],
      },
      {
        path: '/China/ImportChina',
        name: 'ImportChina',
        meta: {
          title: "境外输入疫情"
        },
        component: () => import('@/views/China/ImportChina.vue'),
      },
      {
        path: '/Province/provinceData',
        name: 'provinceData',
        meta: {
          title: "省份数据统计"
        },
        component: () => import('@/views/Province/provinceData.vue'),
      },
      {
        path: '/Province/provinceCompare',
        name: 'provinceCompare',
        meta: {
          title: "各省数据比较"
        },
        component: () => import('@/views/Province/provinceCompare.vue'),
      },
      {
        path: '/Province/BeijingMap',
        name: 'provinceCompare',
        meta: {
          title: "北京疫情地图"
        },
        component: () => import('@/views/Province/BeijingMap.vue'),
      },

      {
        path: '/World/WorldData',
        name: 'WorldData',
        meta: {
          title: "世界疫情统计数据"
        },
        component: () => import('@/views/World/WorldData.vue'),
      },
      {
        path: '/World/NowData',
        name: 'WorldData',
        meta: {
          title: "世界疫情当天数据"
        },
        component: () => import('@/views/World/NowData.vue'),
      },
      {
        path: '/World/WorldDataTrend',
        name: 'WorldDataTrend',
        meta: {
          title: "世界疫情趋势"
        },
        component: () => import('@/views/World/WorldDataTrend.vue'),
        children: [
          {
            path: '/World/WorldDataTrend/Append',
            name: 'Append',
            meta: {
              title: "世界最近一星期新增确诊"
            },
            component: () => import('@/views/Echarts/World/Append.vue'),
          },
          {
            path: '/World/WorldDataTrend/Cured',
            name: 'Cured',
            meta: {
              title: "世界最近一星期治愈人数趋势"
            },
            component: () => import('@/views/Echarts/World/Cured.vue'),
          },
          {
            path: '/World/WorldDataTrend/Dead',
            name: 'Dead',
            meta: {
              title: "世界最近一星期死亡人数趋势"
            },
            component: () => import('@/views/Echarts/World/Dead.vue'),
          },
          {
            path: '/World/WorldDataTrend/Suspected',
            name: 'Suspected',
            meta: {
              title: "世界最近一星期疑似确诊人数趋势"
            },
            component: () => import('@/views/Echarts/World/Suspected.vue'),
          },
        ],
      },
      {
        path: '/World/ShowNationData',
        name: 'ShowNationData',
        meta: {
          title: "展示各国数据"
        },
        component: () => import('@/views/World/ShowNationData.vue'),
        children: [
          {
            path: '/World/ShowNationData/Append',
            name: 'Append',
            meta: {
              title: "世界前10个国家确诊人数排名"
            },
            component: () => import('@/views/Echarts/ShowWorldData/Append.vue'),
          },
          {
            path: '/World/ShowNationData/Cured',
            name: 'Cured',
            meta: {
              title: "世界前10个国家治愈人数排名"
            },
            component: () => import('@/views/Echarts/ShowWorldData/Cured.vue'),
          },
          {
            path: '/World/ShowNationData/Dead',
            name: 'Dead',
            meta: {
              title: "世界前10个国家死亡人数排名"
            },
            component: () => import('@/views/Echarts/ShowWorldData/Dead.vue'),
          },
          {
            path: '/World/ShowNationData/Suspected',
            name: 'Suspected',
            meta: {
              title: "世界前10个国家疑似人数排名"
            },
            component: () => import('@/views/Echarts/ShowWorldData/Suspected.vue'),
          },
        ],
      },
      {
        path: '/China/Population',
        name: 'Population',
        meta: {
          title: "世界疫情统计数据"
        },
        component: () => import('@/views/China/Population.vue'),
      },
      {
        path: '/China/Goods',
        name: 'Goods',
        meta: {
          title: "世界疫情统计数据"
        },
        component: () => import('@/views/China/Goods.vue'),
      },
    ]
  },


]

// 3.创建路由的实例对象
const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

// 4.向外共享路由的实例对象
export default router
