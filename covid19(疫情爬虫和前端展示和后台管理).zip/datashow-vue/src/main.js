// 导入vue的包，得到vue的构造函数
import Vue from 'vue'
// 导入App.vue根组件，将来要把App.vue中的模板结构，渲染到html中
import App from './App.vue'
// 导入路由模块
import router from './router'
import store from './store'

// 导入element-ui依赖
import Element from 'element-ui'
import "element-ui/lib/theme-chalk/index.css"
// 调用Vue.use()函数，把Element安装为Vue的插件
Vue.use(Element)

// 导入axios全局
import axios from 'axios'
//后端的入口
axios.defaults.baseURL = "http://localhost:8084"
Vue.prototype.$axios = axios

// 在vue实例挂载moment方法
import moment from 'moment'
Vue.prototype.$moment = moment


Vue.config.productionTip = false

// 创建Vue的实例对象
new Vue({
  // 挂载路由模块
  router,
  store,
  
  // 把render函数指定的App组件，渲染到html页面中，
  // 也就是将vue文件替换掉html中带有id的标签
  render: h => h(App)
})
// 相当于el:'#app'
.$mount('#app')
