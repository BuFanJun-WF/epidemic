<template>
  <!-- 在template中只能有一个div，就是最外层的div -->
  <div id="app">
    <!-- 2.定义路由的占位符 -->
    <router-view />
  </div>
</template>
<script>
export default {
  name: "App",
  
};
</script>



<style>
html,
body,
#app {
  font-family: "Helvetica Neue", "Hiragino Sans GB", "WenQuanYi Micro Hei",
    "Microsoft Yahei", sans-serif;
  height: 100%;
  padding: 0;
  margin: 0;
  font-size: 20px;
}
</style>
