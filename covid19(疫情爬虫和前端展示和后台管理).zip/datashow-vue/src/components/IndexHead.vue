<template>
    <el-row :gutter="20">
      <el-col :xs="24" :sm="12" :md="8" :lg="4" :xl="4">
        <div class="grid-content bg-purple">
          <div class="follow">当前时间</div>
          <div class="under">{{covid19china1.dateTime}}</div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="12" :md="8" :lg="4" :xl="4">
        <div class="grid-content bg-purple">
          <div class="follow">现存确诊</div>
          <div class="under">{{covid19china1.currentConfirmedCount}}</div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="12" :md="8" :lg="4" :xl="4">
        <div class="grid-content bg-purple">
          <div class="follow">累计确诊</div>
          <div class="under">{{covid19china1.confirmedCount}}</div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="12" :md="8" :lg="4" :xl="4">
        <div class="grid-content bg-purple">
          <div class="follow">疑似病例</div>
          <div class="under">{{covid19china1.suspectedCount}}</div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="12" :md="8" :lg="4" :xl="4">
        <div class="grid-content bg-purple">
          <div class="follow">累计治愈</div>
          <div class="under">{{covid19china1.curedCount}}</div>
        </div>
      </el-col>
      <el-col :xs="24" :sm="12" :md="8" :lg="4" :xl="4">
        <div class="grid-content bg-purple">
          <div class="follow">累计死亡</div>
          <div class="under">{{covid19china1.deadCount}}</div>
        </div>
      </el-col>
    </el-row>
</template>
<script>
export default {
  name: "IndexHead",
  props: ['date','covid19china1'],
  data() {
    return {
      
    };
  },

  methods: {
    
  },
};
</script>

<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}

.bg-purple {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
  border-radius: 2px;
  background: #ffffff;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
.follow {
  border-bottom: 3px solid #f2f2f2;
  padding: 10px;
}
.under {
  border-bottom: 1px solid #f2f2f2;
  padding: 10px;
}
</style>