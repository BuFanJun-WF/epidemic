<template>
  <el-row :gutter="20">
    <el-col :span="18"
      ><div class="grid-content bg-purple">
        <AllTime></AllTime></div
    ></el-col>
    <el-col :span="6"><div class="grid-content bg-purple">
        <OneDay></OneDay>
        </div></el-col>
  </el-row>
</template>

<script>
import AllTime from "../views/Echarts/Index/AllTime.vue";
import OneDay from "../views/Echarts/Index/OneDay.vue";
export default {
  name: "IndexMain",
  props: [],
  components: {
    AllTime,
    OneDay,
  },
};
</script>

<style scoped>
.el-row .el-col {
  margin-bottom: 20px;
  text-align: center;
}

.bg-purple {
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.12), 0 0 6px rgba(0, 0, 0, 0.04);
  border-radius: 2px;
  background: #ffffff;
  height: 500px;
}
.grid-content {
  border-radius: 4px;
  min-height: 36px;
}
</style>