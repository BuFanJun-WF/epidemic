package com.wangfan.bean

/**
 * @author bufanjun
 * @date 2021/7/28 0027
 * @Desc
 */
case class ChinaCovidBean(
                      /**
                       * 省会名称
                       */
                      provinceName: String,

                      /**
                       * 省会的短名
                       */
                      provinceShortName: String,

                      /**
                       * 城市名字
                       */
                      cityName: String,

                      /**
                       * 当前确诊人数
                       */
                      currentConfirmedCount: Integer,

                      /**
                       * 累计确诊人数
                       */
                      confirmedCount: Integer,

                      /**
                       * 疑似病例人数
                       */
                      suspectedCount: Integer,

                      /**
                       * 治愈人数
                       */
                      curedCount: Integer,

                      /**
                       * 死亡人数
                       */
                      deadCount: Integer,

                      /**
                       * 自带位置ID
                       */
                      locationId: Integer,

                      /**
                       * 省会ID
                       */
                      pid: Integer,

                      /**
                       * 下属城市
                       */
                      cities: String,

                      /**
                       * 每一天的统计数据
                       */
                      statisticsData: String,

                      /**
                       * 城市统计的日期
                       */
                      datetime: String
                    )
