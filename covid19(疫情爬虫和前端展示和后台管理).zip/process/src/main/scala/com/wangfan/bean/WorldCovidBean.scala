package com.wangfan.bean

/**
 * @author 陈子创
 * @date 2021/7/28 0027
 * @Desc
 */
case class WorldCovidBean(
                           continents: String, //大洲
                           provinceName: String, //国家名称
                           countryShortCode: String,//国家简称
                           countryFullName: String,//国家全称
                           locationId: Integer,//位置
                           currentConfirmedCount: Integer, //当前确诊
                           confirmedCount: Integer,//累计确诊
                           confirmedCountRank: Integer,//累计确诊排名
                           suspectedCount: Integer,//疑似病例
                           curedCount: Integer,//治愈数
                           deadCount: Integer,//死亡数
                           deadCountRank: Integer,//死亡数排名
                           statisticsData: String,//统计数据
                           dateTime: String//日期

)
