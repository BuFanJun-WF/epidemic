package com.wangfan.bean

/**
 * @author 陈子创
 * @date 2021/7/28 0027
 * @Desc 用来封装国家每一天的统计数据
 */
case class WorldStatisticsDataBean(
                               //当天日期
                               var dateId: String,
                               //国家名称
                               var provinceName: String,
                               //国家编码
                               var locationId:Int,
                               //累计确诊人数
                               var confirmedCount: Int,
                               //当前确诊人数
                               var currentConfirmedCount: Int,
                               //确诊新增人数
                               var confirmedIncr: Int,
                               //累计治愈人数
                               var curedCount: Int,
                               //当前确诊新增人数
                               var currentConfirmedIncr: Int,
                               //痊愈新增人数
                               var curedIncr: Int,
                               //疑似人数
                               var suspectedCount: Int,
                               //疑似新增人数
                               var suspectedCountIncr: Int,
                               //死亡人数
                               var deadCount: Int,
                               //死亡新增人数
                               var deadIncr: Int

                             )

