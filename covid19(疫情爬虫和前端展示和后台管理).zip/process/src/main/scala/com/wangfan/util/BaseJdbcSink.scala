package com.wangfan.util

import org.apache.spark.sql.{ForeachWriter, Row}
import java.sql.{Connection, DriverManager, PreparedStatement}

/**
 * @author bufanjun
 * @date 2021/7/28 0027
 * @Desc
 */
abstract class BaseJdbcSink(sql:String) extends ForeachWriter[Row]{
  var conn: Connection = _
  var ps: PreparedStatement = _

  //开启连接
  override def open(partitionId: Long, version: Long): Boolean = {
    conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/bigdata?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai&useSSL=false", "root", "root")
    true
  }

  //处理数据--将数据存入到MySQL
  override def process(value: Row): Unit = {
    realProcess(sql,value)
  }

  def realProcess(sql:String,value: Row)

  //关闭连接资源
  override def close(errorOrNull: Throwable): Unit = {
    if (conn != null) {
      conn.close()
    }
    if (ps != null) {
      ps.close()
    }
  }

}
