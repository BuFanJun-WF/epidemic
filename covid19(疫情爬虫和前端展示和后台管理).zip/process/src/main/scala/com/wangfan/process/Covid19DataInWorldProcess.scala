package com.wangfan.process

import com.alibaba.fastjson.JSON
import com.wangfan.bean.{ChinaCovidBean, StatisticsDataBean, WorldCovidBean, WorldStatisticsDataBean}
import com.wangfan.util.BaseJdbcSink
import org.apache.spark.SparkContext
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

import scala.collection.immutable.StringOps
import scala.collection.mutable


/**
 * @author bufanjun
 * @date 2021/7/27 0027
 * @Desc 全国各省市疫情数据实时处理统计分析
 */
object Covid19DataInWorldProcess {
  def main(args: Array[String]): Unit = {
    //1.创建StructuredStreaming执行环境
    //StructuredStreaming支持使用SQL来处理实时流数据，数据抽象和SparkSQL一样，也是DataFrame和DataSet
    //所以这里创建StructureSteaming执行环境就直接创建SparkSession即可
    val spark: SparkSession = SparkSession.builder().master("local[*]").appName("Covid19DataInWorldProcess").getOrCreate()
    val sparkContext: SparkContext = spark.sparkContext
    sparkContext.setLogLevel("WARN")
    //导入隐式转换方便后续使用
    import spark.implicits._
    //导入spark一些内置函数
    import org.apache.spark.sql.functions._

    import scala.collection.JavaConversions._

    //2.连接kafka
    //从kafka接收信息
    val kafkaDF: DataFrame = spark.readStream
      .format("kafka")
      //Kafka集群地址
      .option("kafka.bootstrap.servers", "hadoop1:9092,hadoop2:9092,hadoop3:9092")
      //设置主题
      .option("subscribe", "covid19")
      .load()
    //取出消息中的value
    val jsonStrDS: Dataset[String] = kafkaDF.selectExpr("CAST(value AS STRING)").as[String]
    /*jsonStrDS.writeStream
      //输出目的地
      .format("console")
      //输出模式，默认就是append表示显示新增行
      .outputMode("append")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start().awaitTermination()
     */
    //3.处理数据
    //将jsonStr转为样例类
    val covidBeanDS: Dataset[WorldCovidBean] = jsonStrDS.map(jsonStr => {
      //注意：scala中获取class对象使用classOf[类名]
      //java中使用类名.class/Class.forName(全类路径）/对象.getClass()
      JSON.parseObject(jsonStr, classOf[WorldCovidBean])
    })

    //分离出各国家每一天的统计数据
    val statisticsDS: Dataset[WorldStatisticsDataBean] = covidBeanDS.flatMap(p => {
      //获取到的是该国家每一天的统计数据组成的jsonStr数组
      val jsonStr: StringOps = p.statisticsData
      val list: mutable.Buffer[WorldStatisticsDataBean] = JSON.parseArray(jsonStr, classOf[WorldStatisticsDataBean])
      val newList: mutable.Buffer[WorldStatisticsDataBean] = list.map(s => {
        s.provinceName = p.provinceName
        s.locationId = p.locationId
        s
      })
      newList
    })

    /*
    statisticsDS.writeStream
      //输出目的地
      .format("console")
      //输出模式，默认就是append表示显示新增行
      .outputMode("append")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
      //
      .awaitTermination()
     */



    //4.统计分析
    //4.1 全球疫情汇总信息：现有确诊，累计确诊，现有疑似，累计治愈，累计死亡---注意：按照日期分组统计
    val result1: DataFrame = covidBeanDS.groupBy('datetime).agg(
      //现有确诊
      sum('currentConfirmedCount) as "currentConfirmedCount",
      //累计确诊
      sum('confirmedCount) as "confirmedCount",
      //现有疑似
      sum('suspectedCount) as "suspectedCount",
      //累计治愈
      sum('curedCount) as "curedCount",
      //累计死亡
      sum('deadCount) as "deadCount"
    )
    //4.2 全球各国累计确诊数地图--注意：按照日期--国家分组
    val result2: DataFrame = covidBeanDS.select('datetime, 'locationId, 'provinceName, 'currentConfirmedCount, 'confirmedCount, 'suspectedCount, 'curedCount, 'deadCount)

    //4.3全球疫情趋势--注意：按照日期分组聚合
    val result3: DataFrame = statisticsDS.groupBy('dateId).agg(
      //新增确诊
      sum('confirmedIncr) as "confirmedIncr",
      //累计确诊人数
      sum('confirmedCount) as "confirmedCount",
      //累计疑似病例
      sum('suspectedCount) as "suspectedCount",
      //累计治愈病例
      sum('curedCount) as "curedCount",
      //累计死亡人数
      sum('deadCount) as "deadCount"
    )

    //4.4 统计各大洲的累计确诊地图
val result4: DataFrame = covidBeanDS.groupBy('continents).agg(
  //现有确诊
  sum('currentConfirmedCount) as "currentConfirmedCount",
  //累计确诊人数
  sum('confirmedCount) as "confirmedCount",
  //累计疑似病例
  sum('suspectedCount) as "suspectedCount",
  //累计治愈病例
  sum('curedCount) as "curedCount",
  //累计死亡人数
  sum('deadCount) as "deadCount"
)


    //5.输出结果先在控制台输出，后入库

//    result1.writeStream
//      .format("console")
//      //输出模式：
//      //1.append：默认的，表示只输出新增的数据，只支持简单的查询，不支持聚合
//      //2.complete：表示完整模式，所有数据都会输出，必须包含聚合操作
//      //3.update：表示更新模式，只输出有变化的数据，不支持排序
//      .outputMode("complete")
//      .trigger(Trigger.ProcessingTime(0))
//      .option("truncate", value = false)
//      .start()
//      //.awaitTermination()

//    result2.writeStream
//      .format("console")
//      //输出模式：
//      //1.append：默认的，表示只输出新增的数据，只支持简单的查询，不支持聚合
//      //2.complete：表示完整模式，所有数据都会输出，必须包含聚合操作
//      //3.update：表示更新模式，只输出有变化的数据，不支持排序
//      .outputMode("append")
//      .trigger(Trigger.ProcessingTime(0))
//      .option("truncate", value = false)
//      .start()
    //.awaitTermination()

//    result3.writeStream
//      .format("console")
//      //输出模式：
//      //1.append：默认的，表示只输出新增的数据，只支持简单的查询，不支持聚合
//      //2.complete：表示完整模式，所有数据都会输出，必须包含聚合操作
//      //3.update：表示更新模式，只输出有变化的数据，不支持排序
//      .outputMode("complete")
//      .trigger(Trigger.ProcessingTime(0))
//      .option("truncate", value = false)
//      .start()
//      //.awaitTermination()

    //result4.writeStream
    //  .format("console")
    //  //输出模式：
    //  //1.append：默认的，表示只输出新增的数据，只支持简单的查询，不支持聚合
    //  //2.complete：表示完整模式，所有数据都会输出，必须包含聚合操作
    //  //3.update：表示更新模式，只输出有变化的数据，不支持排序
    //  .outputMode("complete")
    //  .trigger(Trigger.ProcessingTime(0))
    //  .option("truncate", value = false)
    //  .start()
//    .awaitTermination()



//    CREATE TABLE `covid19_world1` (
//      `datetime` varchar(20) NOT NULL DEFAULT '',
//    `currentConfirmedCount` bigint(20) DEFAULT NULL,
//    `confirmedCount` bigint(20) DEFAULT NULL,
//    `suspectedCount` bigint(20) DEFAULT NULL,
//    `curedCount` bigint(20) DEFAULT NULL,
//    `deadCount` bigint(20) DEFAULT NULL,
//    PRIMARY KEY (`datetime`)
//    ) ENGINE=InnoDB DEFAULT CHARSET=utf8                       date_time,current_confirmed_count,confirmed_count,suspected_count,cured_count,dead_count
    result1.writeStream
      .foreach(new BaseJdbcSink(sql = "replace into covid19_world1 (date_time,current_confirmed_count,confirmed_count,suspected_count,cured_count,dead_count) values (?,?,?,?,?,?)") {
        override def realProcess(sql: String, value: Row): Unit = {
          val datetime: String = value.getAs[String]("datetime")
          val currentConfirmedCount: Long = value.getAs[Long]("currentConfirmedCount")
          val confirmedCount: Long = value.getAs[Long]("confirmedCount")
          val suspectedCount: Long = value.getAs[Long]("suspectedCount")
          val curedCount: Long = value.getAs[Long]("curedCount")
          val deadCount: Long = value.getAs[Long]("deadCount")
          //获取预编译语句对象
          ps = conn.prepareStatement(sql)
          //给sql设置值
          ps.setString(1,datetime)
          ps.setLong(2,currentConfirmedCount)
          ps.setLong(3,confirmedCount)
          ps.setLong(4,suspectedCount)
          ps.setLong(5,curedCount)
          ps.setLong(6,deadCount)
          ps.executeUpdate()
        }
      }).outputMode("complete")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
//      .awaitTermination()
//
//
////    CREATE TABLE `covid19_world2` (
////      `datetime` VARCHAR(20)  NOT NULL DEFAULT '',
////    `locationId` INT(11) NOT NULL DEFAULT '0',
////    `provinceName` VARCHAR(20) DEFAULT NULL,
////    `currentConfirmedCount` INT(11) DEFAULT NULL,
////    `confirmedCount` INT(11) DEFAULT NULL,
////    `suspectedCount` INT(11) DEFAULT NULL,
////    `curedCount` INT(11) DEFAULT NULL,
////    `deadCount` INT(11) DEFAULT NULL,
////    PRIMARY KEY (`datetime`,`locationId`)
////    ) ENGINE=INNODB DEFAULT CHARSET=utf8;                  date_time,location_id,province_name,current_confirmed_count,confirmed_count,suspected_count,cured_count,dead_count
    result2.writeStream
      .foreach(new BaseJdbcSink(sql = "replace into covid19_world2 (date_time,location_id,province_name,current_confirmed_count,confirmed_count,suspected_count,cured_count,dead_count) values (?,?,?,?,?,?,?,?)") {
        override def realProcess(sql: String, value: Row): Unit = {
          val datetime: String = value.getAs[String]("datetime")
          val locationId: Int = value.getAs[Int]("locationId")
          val provinceName: String = value.getAs[String]("provinceName")
          val currentConfirmedCount: Int = value.getAs[Int]("currentConfirmedCount")
          val confirmedCount: Int = value.getAs[Int]("confirmedCount")
          val suspectedCount: Int = value.getAs[Int]("suspectedCount")
          val curedCount: Int = value.getAs[Int]("curedCount")
          val deadCount: Int = value.getAs[Int]("deadCount")
          //获取预编译语句对象
          ps = conn.prepareStatement(sql)
          //给sql设置值
          ps.setString(1,datetime)
          ps.setInt(2,locationId)
          ps.setString(3,provinceName)
          ps.setInt(4,currentConfirmedCount)
          ps.setInt(5,confirmedCount)
          ps.setInt(6,suspectedCount)
          ps.setInt(7,curedCount)
          ps.setInt(8,deadCount)
          ps.executeUpdate()
        }
      }).outputMode("append")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
////      .awaitTermination()
//
////    CREATE TABLE `covid19_world3` (
////      `dateId` VARCHAR(20)  NOT NULL DEFAULT '',
////    `confirmedIncr` BIGINT(20) DEFAULT NULL,
////    `confirmedCount` BIGINT(20) DEFAULT NULL,
////    `suspectedCount` BIGINT(20) DEFAULT NULL,
////    `curedCount` BIGINT(20) DEFAULT NULL,
////    `deadCount` BIGINT(20) DEFAULT NULL,
////    PRIMARY KEY (`dateId`)
////    ) ENGINE=INNODB DEFAULT CHARSET=utf8;                     date_id,confirmed_incr,confirmed_count,suspected_count,cured_count,dead_count
    result3.writeStream
      .foreach(new BaseJdbcSink(sql = "replace into covid19_world3 (date_id,confirmed_incr,confirmed_count,suspected_count,cured_count,dead_count) values (?,?,?,?,?,?)") {
        override def realProcess(sql: String, value: Row): Unit = {
          val dateId: String = value.getAs[String]("dateId")
          val confirmedIncr: Long = value.getAs[Long]("confirmedIncr")
          val confirmedCount: Long = value.getAs[Long]("confirmedCount")
          val suspectedCount: Long = value.getAs[Long]("suspectedCount")
          val curedCount: Long = value.getAs[Long]("curedCount")
          val deadCount: Long = value.getAs[Long]("deadCount")
          //获取预编译语句对象
          ps = conn.prepareStatement(sql)
          //给sql设置值
          ps.setString(1,dateId)
          ps.setLong(2,confirmedIncr)
          ps.setLong(3,confirmedCount)
          ps.setLong(4,suspectedCount)
          ps.setLong(5,curedCount)
          ps.setLong(6,deadCount)
          //执行sql
          ps.executeUpdate()
        }
      }).outputMode("complete")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
////      .awaitTermination()
//
//    CREATE TABLE `covid19_world4` (
//    `continents` VARCHAR(20) NOT NULL DEFAULT '',
//    `currentConfirmedCount` BIGINT(20) DEFAULT NULL,
//    `confirmedCount` BIGINT(20) DEFAULT NULL,
//    `suspectedCount` BIGINT(20) DEFAULT NULL,
//    `curedCount` BIGINT(20) DEFAULT NULL,
//    `deadCount` BIGINT(20) DEFAULT NULL,
//    PRIMARY KEY (`continents`)
//    ) ENGINE=INNODB DEFAULT CHARSET=utf8
    result4.writeStream
      .foreach(new BaseJdbcSink(sql = "replace into covid19_world4 (continents,current_confirmed_count,confirmed_count,suspected_count,cured_count,dead_count) values (?,?,?,?,?,?)") {
        override def realProcess(sql: String, value: Row): Unit = {
          val continents: String = value.getAs[String]("continents")
          val currentConfirmedCount: Long = value.getAs[Long]("currentConfirmedCount")
          val confirmedCount: Long = value.getAs[Long]("confirmedCount")
          val suspectedCount: Long = value.getAs[Long]("suspectedCount")
          val curedCount: Long = value.getAs[Long]("curedCount")
          val deadCount: Long = value.getAs[Long]("deadCount")
          //获取预编译语句对象
          ps = conn.prepareStatement(sql)
          //给sql设置值
          ps.setString(1,continents)
          ps.setLong(2,currentConfirmedCount)
          ps.setLong(3,confirmedCount)
          ps.setLong(4,suspectedCount)
          ps.setLong(5,curedCount)
          ps.setLong(6,deadCount)
          ps.executeUpdate()
        }
      }).outputMode("complete")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
      .awaitTermination()
  }
}
