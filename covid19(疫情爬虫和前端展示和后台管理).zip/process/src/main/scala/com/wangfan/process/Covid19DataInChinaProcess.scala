package com.wangfan.process

import com.alibaba.fastjson.JSON
import com.wangfan.bean.{ChinaCovidBean, StatisticsDataBean}
import com.wangfan.util.BaseJdbcSink
import org.apache.spark.SparkContext
import org.apache.spark.sql.streaming.Trigger
import org.apache.spark.sql.{DataFrame, Dataset, ForeachWriter, Row, SparkSession}

import java.util
import scala.collection.immutable.StringOps
import scala.collection.mutable


/**
 * @author bufanjun
 * @date 2021/7/27 0027
 * @Desc 全国各省市疫情数据实时处理统计分析
 */
object Covid19DataInChinaProcess {
  def main(args: Array[String]): Unit = {
    //1.创建StructuredStreaming执行环境
    //StructuredStreaming支持使用SQL来处理实时流数据，数据抽象和SparkSQL一样，也是DataFrame和DataSet
    //所以这里创建StructureSteaming执行环境就直接创建SparkSession即可
    val spark: SparkSession = SparkSession.builder().master("local[*]").appName("Covid19DataInChinaProcess").getOrCreate()
    val sparkContext: SparkContext = spark.sparkContext
    sparkContext.setLogLevel("WARN")
    //导入隐式转换方便后续使用
    import spark.implicits._
    //导入spark一些内置函数
    import  org.apache.spark.sql.functions._

    import scala.collection.JavaConversions._

    //2.连接kafka
    //从kafka接收信息
    val kafkaDF: DataFrame = spark.readStream
      .format("kafka")
      //Kafka集群地址
      .option("kafka.bootstrap.servers", "hadoop1:9092,hadoop2:9092,hadoop3:9092")
      //设置主题
      .option("subscribe", "covid19")
      .load()
    //取出消息中的value
    val jsonStrDS: Dataset[String] = kafkaDF.selectExpr("CAST(value AS STRING)").as[String]
    /*jsonStrDS.writeStream
      //输出目的地
      .format("console")
      //输出模式，默认就是append表示显示新增行
      .outputMode("append")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start().awaitTermination()
     */
    //3.处理数据
    //将jsonStr转为样例类
    val covidBeanDS: Dataset[ChinaCovidBean] = jsonStrDS.map(jsonStr => {
      //注意：scala中获取class对象使用classOf[类名]
      //java中使用类名.class/Class.forName(全类路径）/对象.getClass()
      JSON.parseObject(jsonStr, classOf[ChinaCovidBean])
    })
    //分离出省份数据
    val provinceDS: Dataset[ChinaCovidBean] = covidBeanDS.filter(_.statisticsData != null)

    //分离出城市数据
    val cityDS: Dataset[ChinaCovidBean] = covidBeanDS.filter(_.statisticsData == null)

    //分离出各省份每一天的统计数据
    val statisticsDS: Dataset[StatisticsDataBean] = provinceDS.flatMap(p => {
      //获取到的是该省份每一天的统计数据组成的jsonStr数组
      val jsonStr: StringOps = p.statisticsData
      val list: mutable.Buffer[StatisticsDataBean] = JSON.parseArray(jsonStr, classOf[StatisticsDataBean])
      val newList: mutable.Buffer[StatisticsDataBean] = list.map(s => {
        s.provinceShortName = p.provinceShortName
        s.locationId = p.locationId
        s
      })
      newList
    })


    //statisticsDS.writeStream
    //  //输出目的地
    //  .format("console")
    //  //输出模式，默认就是append表示显示新增行
    //  .outputMode("append")
    //  //触发间隔，0表示尽可能快的执行
    //  .trigger(Trigger.ProcessingTime(0))
    //  //表示如果列名过长不进行截断
    //  .option("truncate",value = false)
    //  .start()
      /*
      //
      .awaitTermination()
     */



    //4.统计分析
    //4.1 全国疫情汇总信息：现有确诊，累计确诊，现有疑似，累计治愈，累计死亡---注意：按照日期分组统计
    val result1: DataFrame = provinceDS.groupBy('datetime).agg(
      //现有确诊
      sum('currentConfirmedCount) as "currentConfirmedCount",
      //累计确诊
      sum('confirmedCount) as "confirmedCount",
      //现有疑似
      sum('suspectedCount) as "suspectedCount",
      //累计治愈
      sum('curedCount) as "curedCount",
      //累计死亡
      sum('deadCount) as "deadCount"
    )
    //4.2 全国各省份累计确诊数地图--注意：按照日期--省份分组
    //cityDS.groupBy('datetime,'provinceShortName).agg(
    //  sum('confirmedCount) as "confirmedCount"
    //)
    val result2: DataFrame = provinceDS.select('datetime, 'locationId, 'provinceShortName, 'currentConfirmedCount, 'confirmedCount, 'suspectedCount, 'curedCount, 'deadCount)

    //4.3全国疫情趋势--注意：按照日期分组聚合
    val result3: DataFrame = statisticsDS.groupBy('dateId).agg(
      //新增确诊
      sum('confirmedIncr) as "confirmedIncr",
      //累计确诊人数
      sum('confirmedCount) as "confirmedCount",
      //累计疑似病例
      sum('suspectedCount) as "suspectedCount",
      //累计治愈病例
      sum('curedCount) as "curedCount",
      //累计死亡人数
      sum('deadCount) as "deadCount"
    )

    //4.4 境外输入排行--注意：按照日期--城市分组聚合
    val result4: Dataset[Row] = cityDS.filter(_.cityName.contains("境外输入")).groupBy('datetime, 'provinceShortName, 'pid).agg(
      //累计确诊人数
      sum('confirmedCount) as "confirmedCount"
    ).sort(
      'confirmedCount.desc
    )
    //4.5 统计北京市的累计确诊地图
    val result5: DataFrame = cityDS.filter(_.provinceShortName.equals("北京")).select('datetime, 'locationId, 'provinceShortName, 'cityName, 'currentConfirmedCount, 'confirmedCount, 'suspectedCount, 'curedCount, 'deadCount)


    //5.输出结果先在控制台输出，后入库

//    result1.writeStream
//      .format("console")
//      //输出模式：
//      //1.append：默认的，表示只输出新增的数据，只支持简单的查询，不支持聚合
//      //2.complete：表示完整模式，所有数据都会输出，必须包含聚合操作
//      //3.update：表示更新模式，只输出有变化的数据，不支持排序
//      .outputMode("complete")
//      .trigger(Trigger.ProcessingTime(0))
//      .option("truncate", value = false)
//      .start()
      //.awaitTermination()
//
//    +----------+---------------------+--------------+--------------+----------+---------+
//    |datetime  |currentConfirmedCount|confirmedCount|suspectedCount|curedCount|deadCount|
//    +----------+---------------------+--------------+--------------+----------+---------+
//    |2021-08-03|3195                 |120875        |2014          |112043    |5637     |
//      +----------+---------------------+--------------+--------------+----------+---------+

//    result2.writeStream
//      .format("console")
//      //输出模式：
//      //1.append：默认的，表示只输出新增的数据，只支持简单的查询，不支持聚合
//      //2.complete：表示完整模式，所有数据都会输出，必须包含聚合操作
//      //3.update：表示更新模式，只输出有变化的数据，不支持排序
//      .outputMode("append")
//      .trigger(Trigger.ProcessingTime(0))
//      .option("truncate", value = false)
//      .start()
//      //.awaitTermination()
//    +----------+----------+-----------------+---------------------+--------------+--------------+----------+---------+
//    |datetime  |locationId|provinceShortName|currentConfirmedCount|confirmedCount|suspectedCount|curedCount|deadCount|
//    +----------+----------+-----------------+---------------------+--------------+--------------+----------+---------+
//    |2021-08-03|710000    |台湾               |2029                 |15702         |485           |12884     |789      |
//      |2021-08-03|530000    |云南               |380                  |841           |6             |459       |2        |
//      |2021-08-03|320000    |江苏               |344                  |1088          |3             |744       |0        |
//      |2021-08-03|440000    |广东               |73                   |2892          |25            |2811      |8        |
//      |2021-08-03|810000    |香港               |63                   |11990         |181           |11715     |212      |
//      |2021-08-03|310000    |上海               |61                   |2318          |393           |2250      |7        |
//      |2021-08-03|510000    |四川               |43                   |1157          |22            |1111      |3        |
//      |2021-08-03|350000    |福建               |42                   |742           |15            |699       |1        |
//      |2021-08-03|410000    |河南               |31                   |1347          |1             |1294      |22       |
//      |2021-08-03|120000    |天津               |25                   |428           |50            |400       |3        |
//      |2021-08-03|420000    |湖北               |24                   |68201         |25            |63665     |4512     |
//      |2021-08-03|610000    |陕西               |24                   |659           |4             |632       |3        |
//      |2021-08-03|430000    |湖南               |23                   |1091          |2             |1064      |4        |
//      |2021-08-03|110000    |北京               |20                   |1096          |164           |1067      |9        |
//      |2021-08-03|330000    |浙江               |18                   |1396          |68            |1377      |1        |
//      |2021-08-03|210000    |辽宁               |9                    |437           |0             |426       |2        |
//      |2021-08-03|150000    |内蒙古              |9                    |408           |35            |398       |1        |
//      |2021-08-03|370000    |山东               |7                    |890           |14            |876       |7        |
//      |2021-08-03|820000    |澳门               |5                    |59            |9             |54        |0        |
//      |2021-08-03|500000    |重庆               |4                    |603           |15            |593       |6        |
//      +----------+----------+-----------------+---------------------+--------------+--------------+----------+---------+

//    result3.writeStream
//      .format("console")
//      //输出模式：
//      //1.append：默认的，表示只输出新增的数据，只支持简单的查询，不支持聚合
//      //2.complete：表示完整模式，所有数据都会输出，必须包含聚合操作
//      //3.update：表示更新模式，只输出有变化的数据，不支持排序
//      .outputMode("complete")
//      .trigger(Trigger.ProcessingTime(0))
//      .option("truncate", value = false)
//      .start()
//      .awaitTermination()
//    +--------+-------------+--------------+--------------+----------+---------+
//    |dateId  |confirmedIncr|confirmedCount|suspectedCount|curedCount|deadCount|
//    +--------+-------------+--------------+--------------+----------+---------+
//    |20210202|53           |101092        |1801          |93893     |4828     |
//      |20210607|439          |114913        |1821          |99020     |5154     |
//      |20210611|313          |115820        |1821          |99084     |5231     |
//      |20200714|54           |85677         |1504          |80407     |4649     |
//      |20201015|37           |91436         |1773          |86234     |4746     |
//      |20200413|99           |83696         |415           |78262     |3351     |
//      |20200218|1749         |74277         |0             |14378     |2006     |
//      |20210712|83           |119404        |2013          |110552    |5595     |
//      |20210714|57           |119485        |2013          |110656    |5601     |
//      |20210729|62           |120553        |2014          |111864    |5635     |
//      |20201011|28           |91333         |1761          |86157     |4746     |
//      |20200314|27           |81048         |0             |67022     |3204     |
//      |20210211|34           |101463        |1801          |95272     |4836     |
//      |20200311|25           |80980         |0             |62874     |3173     |
//      |20210119|165          |99191         |1787          |92088     |4807     |
//      |20200821|50           |90103         |1668          |84250     |4716     |
//      |20200902|20           |90442         |1671          |85166     |4734     |
//      |20210523|1076         |107791        |1821          |98755     |4875     |
//      |20201016|24           |91460         |1773          |86246     |4746     |
//      |20210603|610          |113068        |1821          |98932     |5012     |
//      +--------+-------------+--------------+--------------+----------+---------+




//        result4.writeStream
//      .format("console")
//      //输出模式：
//      //1.append：默认的，表示只输出新增的数据，只支持简单的查询，不支持聚合
//      //2.complete：表示完整模式，所有数据都会输出，必须包含聚合操作
//      //3.update：表示更新模式，只输出有变化的数据，不支持排序
//      .outputMode("complete")
//      .trigger(Trigger.ProcessingTime(0))
//      .option("truncate", value = false)
//      .start()
//      .awaitTermination()
//    +----------+-----------------+------+--------------+
//    |datetime  |provinceShortName|pid   |confirmedCount|
//    +----------+-----------------+------+--------------+
//    |2021-08-03|上海               |310000|1946          |
//      |2021-08-03|云南               |530000|480           |
//      |2021-08-03|福建               |350000|444           |
//      |2021-08-03|陕西               |610000|413           |
//      |2021-08-03|黑龙江              |230000|392           |
//      |2021-08-03|内蒙古              |150000|303           |
//      |2021-08-03|天津               |120000|281           |
//      |2021-08-03|北京               |110000|263           |
//      |2021-08-03|浙江               |330000|177           |
//      |2021-08-03|江苏               |320000|129           |
//      |2021-08-03|山西               |140000|115           |
//      |2021-08-03|山东               |370000|110           |
//      |2021-08-03|辽宁               |210000|107           |
//      |2021-08-03|甘肃               |620000|107           |
//      |2021-08-03|河南               |410000|61            |
//      |2021-08-03|湖北               |420000|60            |
//      |2021-08-03|湖南               |430000|53            |
//      |2021-08-03|河北               |130000|36            |
//      |2021-08-03|重庆               |500000|25            |
//      |2021-08-03|广西               |450000|24            |
//      +----------+-----------------+------+--------------+





//        result5.writeStream
//      .format("console")
//      //输出模式：
//      //1.append：默认的，表示只输出新增的数据，只支持简单的查询，不支持聚合
//      //2.complete：表示完整模式，所有数据都会输出，必须包含聚合操作
//      //3.update：表示更新模式，只输出有变化的数据，不支持排序
//      .outputMode("append")
//      .trigger(Trigger.ProcessingTime(0))
//      .option("truncate", value = false)
//      .start()
      //.awaitTermination()
//    +----------+----------+-----------------+--------+---------------------+--------------+--------------+----------+---------+
//    |datetime  |locationId|provinceShortName|cityName|currentConfirmedCount|confirmedCount|suspectedCount|curedCount|deadCount|
//    +----------+----------+-----------------+--------+---------------------+--------------+--------------+----------+---------+
//    |2021-08-03|0         |北京               |境外输入    |28                   |263           |3             |235       |0        |
//      |2021-08-03|110114    |北京               |昌平区     |2                    |36            |0             |34        |0        |
//      |2021-08-03|110111    |北京               |房山区     |2                    |22            |0             |20        |0        |
//      |2021-08-03|110108    |北京               |海淀区     |1                    |83            |0             |82        |0        |
//      |2021-08-03|110106    |北京               |丰台区     |0                    |273           |0             |273       |0        |
//      |2021-08-03|110115    |北京               |大兴区     |0                    |134           |0             |134       |0        |
//      |2021-08-03|110105    |北京               |朝阳区     |0                    |80            |0             |80        |0        |
//      |2021-08-03|110102    |北京               |西城区     |0                    |59            |0             |59        |0        |
//      |2021-08-03|110113    |北京               |顺义区     |0                    |45            |0             |45        |0        |
//      |2021-08-03|0         |北京               |外地来京    |0                    |25            |0             |25        |0        |
//      |2021-08-03|110112    |北京               |通州区     |0                    |20            |0             |20        |0        |
//      |2021-08-03|110101    |北京               |东城区     |0                    |19            |0             |19        |0        |
//      |2021-08-03|110107    |北京               |石景山区    |0                    |15            |0             |15        |0        |
//      |2021-08-03|110116    |北京               |怀柔区     |0                    |8             |0             |8         |0        |
//      |2021-08-03|110118    |北京               |密云区     |0                    |7             |0             |7         |0        |
//      |2021-08-03|110109    |北京               |门头沟区    |0                    |5             |0             |5         |0        |
//      |2021-08-03|110119    |北京               |延庆区     |0                    |1             |0             |1         |0        |
//      |2021-08-03|0         |北京               |待明确地区   |-13                  |1             |0             |5         |9        |
//      +----------+----------+-----------------+--------+---------------------+--------------+--------------+----------+---------+




    //    CREATE TABLE `covid19_china1` (
//      `datetime` varchar(20) NOT NULL DEFAULT '',
//    `currentConfirmedCount` bigint(20) DEFAULT NULL,
//    `confirmedCount` bigint(20) DEFAULT NULL,
//    `suspectedCount` bigint(20) DEFAULT NULL,
//    `curedCount` bigint(20) DEFAULT NULL,
//    `deadCount` bigint(20) DEFAULT NULL,
//    PRIMARY KEY (`datetime`)
//    ) ENGINE=InnoDB DEFAULT CHARSET=utf8
    result1.writeStream
      .foreach(new BaseJdbcSink(sql = "replace into covid19_china1 (date_time,current_confirmed_count,confirmed_count,suspected_count,cured_count,dead_count) values (?,?,?,?,?,?)") {
        override def realProcess(sql: String, value: Row): Unit = {
          val datetime: String = value.getAs[String]("datetime")
          val currentConfirmedCount: Long = value.getAs[Long]("currentConfirmedCount")
          val confirmedCount: Long = value.getAs[Long]("confirmedCount")
          val suspectedCount: Long = value.getAs[Long]("suspectedCount")
          val curedCount: Long = value.getAs[Long]("curedCount")
          val deadCount: Long = value.getAs[Long]("deadCount")
          //获取预编译语句对象
          ps = conn.prepareStatement(sql)
          //给sql设置值
          ps.setString(1,datetime)
          ps.setLong(2,currentConfirmedCount)
          ps.setLong(3,confirmedCount)
          ps.setLong(4,suspectedCount)
          ps.setLong(5,curedCount)
          ps.setLong(6,deadCount)
          ps.executeUpdate()
        }
      }).outputMode("complete")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
//      .awaitTermination()
//
//
//    CREATE TABLE `covid19_china2` (
//      `datetime` VARCHAR(20)  NOT NULL DEFAULT '',
//    `locationId` INT(11) NOT NULL DEFAULT '0',
//    `provinceShortName` VARCHAR(20) DEFAULT NULL,
//    `cityName` VARCHAR(20) DEFAULT NULL,
//    `currentConfirmedCount` INT(11) DEFAULT NULL,
//    `confirmedCount` INT(11) DEFAULT NULL,
//    `suspectedCount` INT(11) DEFAULT NULL,
//    `curedCount` INT(11) DEFAULT NULL,
//    `deadCount` INT(11) DEFAULT NULL,
//    `pid` INT(11) DEFAULT NULL,
//    PRIMARY KEY (`datetime`,`locationId`)
//    ) ENGINE=INNODB DEFAULT CHARSET=utf8;
    result2.writeStream
      .foreach(new BaseJdbcSink(sql = "replace into covid19_china2 (date_time,location_id,province_short_name,current_confirmed_count,confirmed_count,suspected_count,cured_count,dead_count) values (?,?,?,?,?,?,?,?)") {
        override def realProcess(sql: String, value: Row): Unit = {
          val datetime: String = value.getAs[String]("datetime")
          val locationId: Int = value.getAs[Int]("locationId")
          val provinceShortName: String = value.getAs[String]("provinceShortName")
          val currentConfirmedCount: Int = value.getAs[Int]("currentConfirmedCount")
          val confirmedCount: Int = value.getAs[Int]("confirmedCount")
          val suspectedCount: Int = value.getAs[Int]("suspectedCount")
          val curedCount: Int = value.getAs[Int]("curedCount")
          val deadCount: Int = value.getAs[Int]("deadCount")
          //获取预编译语句对象
          ps = conn.prepareStatement(sql)
          //给sql设置值
          ps.setString(1,datetime)
          ps.setInt(2,locationId)
          ps.setString(3,provinceShortName)
          ps.setInt(4,currentConfirmedCount)
          ps.setInt(5,confirmedCount)
          ps.setInt(6,suspectedCount)
          ps.setInt(7,curedCount)
          ps.setInt(8,deadCount)
          ps.executeUpdate()
        }
      }).outputMode("append")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
//      .awaitTermination()
//
////    CREATE TABLE `covid19_china3` (
////      `dateId` VARCHAR(20)  NOT NULL DEFAULT '',
////    `confirmedIncr` BIGINT(20) DEFAULT NULL,
////    `confirmedCount` BIGINT(20) DEFAULT NULL,
////    `suspectedCount` BIGINT(20) DEFAULT NULL,
////    `curedCount` BIGINT(20) DEFAULT NULL,
////    `deadCount` BIGINT(20) DEFAULT NULL,
////    PRIMARY KEY (`dateId`)
////    ) ENGINE=INNODB DEFAULT CHARSET=utf8;
    result3.writeStream
      .foreach(new BaseJdbcSink(sql = "replace into covid19_china3 (date_id,confirmed_incr,confirmed_count,suspected_count,cured_count,dead_count) values (?,?,?,?,?,?)") {
        override def realProcess(sql: String, value: Row): Unit = {
          val dateId: String = value.getAs[String]("dateId")
          val confirmedIncr: Long = value.getAs[Long]("confirmedIncr")
          val confirmedCount: Long = value.getAs[Long]("confirmedCount")
          val suspectedCount: Long = value.getAs[Long]("suspectedCount")
          val curedCount: Long = value.getAs[Long]("curedCount")
          val deadCount: Long = value.getAs[Long]("deadCount")
          //获取预编译语句对象
          ps = conn.prepareStatement(sql)
          //给sql设置值
          ps.setString(1,dateId)
          ps.setLong(2,confirmedIncr)
          ps.setLong(3,confirmedCount)
          ps.setLong(4,suspectedCount)
          ps.setLong(5,curedCount)
          ps.setLong(6,deadCount)
          //执行sql
          ps.executeUpdate()
        }
      }).outputMode("complete")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
//      .awaitTermination()
//
//
////    CREATE TABLE `covid19_china4` (
////      `datetime` VARCHAR(20)  NOT NULL DEFAULT '',
////    `provinceShortName` VARCHAR(20) NOT NULL DEFAULT '',
////    `pid` INT(11) DEFAULT NULL,
////    `confirmedCount` BIGINT(20) DEFAULT NULL,
////    PRIMARY KEY (`datetime`,`provinceShortName`)
////    ) ENGINE=INNODB DEFAULT CHARSET=utf8;
    result4.writeStream
      .foreach(new BaseJdbcSink(sql = "replace into covid19_china4 (date_time,province_short_name,pid,confirmed_count) values (?,?,?,?)") {
        override def realProcess(sql: String, value: Row): Unit = {
          val datetime: String = value.getAs[String]("datetime")
          val provinceShortName: String = value.getAs[String]("provinceShortName")
          val pid: Int = value.getAs[Int]("pid")
          val confirmedCount: Long = value.getAs[Long]("confirmedCount")
          //获取预编译语句对象
          ps = conn.prepareStatement(sql)
          //给sql设置值
          ps.setString(1,datetime)
          ps.setString(2,provinceShortName)
          ps.setInt(3,pid)
          ps.setLong(4,confirmedCount)
          //执行sql
          ps.executeUpdate()
        }
      }).outputMode("complete")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
//      .awaitTermination()
//
////    CREATE TABLE `covid19_china5` (
////      `datetime` VARCHAR(20) NOT NULL DEFAULT '',
////    `locationId` INT(11) NOT NULL DEFAULT '0',
////    `provinceShortName` VARCHAR(20) DEFAULT NULL,
////    `cityName` VARCHAR(20) DEFAULT NULL,
////    `currentConfirmedCount` INT(11) DEFAULT NULL,
////    `confirmedCount` INT(11) DEFAULT NULL,
////    `suspectedCount` INT(11) DEFAULT NULL,
////    `curedCount` INT(11) DEFAULT NULL,
////    `deadCount` INT(11) DEFAULT NULL,
////    `pid` INT(11) DEFAULT NULL,
////    PRIMARY KEY (`datetime`,`locationId`)
////    ) ENGINE=INNODB DEFAULT CHARSET=utf8
    result5.writeStream
      .foreach(new BaseJdbcSink(sql = "replace into covid19_china5 (date_time,location_id,province_short_name,city_name,current_confirmed_count,confirmed_count,suspected_count,cured_count,dead_count) values (?,?,?,?,?,?,?,?,?)") {
        override def realProcess(sql: String, value: Row): Unit = {
          val datetime: String = value.getAs[String]("datetime")
          val locationId: Int = value.getAs[Int]("locationId")
          val provinceShortName: String = value.getAs[String]("provinceShortName")
          val cityName: String = value.getAs[String]("cityName")
          val currentConfirmedCount: Int = value.getAs[Int]("currentConfirmedCount")
          val confirmedCount: Int = value.getAs[Int]("confirmedCount")
          val suspectedCount: Int = value.getAs[Int]("suspectedCount")
          val curedCount: Int = value.getAs[Int]("curedCount")
          val deadCount: Int = value.getAs[Int]("deadCount")
          //获取预编译语句对象
          ps = conn.prepareStatement(sql)
          //给sql设置值
          ps.setString(1,datetime)
          ps.setInt(2,locationId)
          ps.setString(3,provinceShortName)
          ps.setString(4,cityName)
          ps.setInt(5,currentConfirmedCount)
          ps.setInt(6,confirmedCount)
          ps.setInt(7,suspectedCount)
          ps.setInt(8,curedCount)
          ps.setInt(9,deadCount)

          ps.executeUpdate()
        }
      }).outputMode("append")
      //触发间隔，0表示尽可能快的执行
      .trigger(Trigger.ProcessingTime(0))
      //表示如果列名过长不进行截断
      .option("truncate",value = false)
      .start()
      .awaitTermination()
  }
}
