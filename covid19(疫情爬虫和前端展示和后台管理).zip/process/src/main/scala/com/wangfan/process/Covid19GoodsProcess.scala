package com.wangfan.process

import com.wangfan.util.OffsetUtils
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.common.TopicPartition
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.kafka010.{CanCommitOffsets, ConsumerStrategies, HasOffsetRanges, KafkaUtils, LocationStrategies, OffsetRange}
import org.apache.spark.{SPARK_BRANCH, SparkConf, SparkContext}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import com.alibaba.fastjson.{JSON, JSONObject}

import java.sql.{Connection, DriverManager, PreparedStatement}
import scala.collection.mutable

object Covid19GoodsProcess {
  def main(args: Array[String]): Unit = {
    // 1.准备SparkStreaming的开发环境
    val conf: SparkConf = new SparkConf().setAppName("Covid19GoodsProcess").setMaster("local[*]")
    val sc: SparkContext = new SparkContext(conf)
    //设置日志级别，让控制台打印的信息进行精简
    sc.setLogLevel("WARN")
    val ssc: StreamingContext = new StreamingContext(sc, Seconds(5))
    ssc.checkpoint("./sscckp")

    // 2.准备kafka的连接参数
    val kafkaParams: Map[String, Object] = Map[String, Object](
      //kafak集群地址
      "bootstrap.servers" -> "hadoop1:9092,hadoop2:9092,hadoop3:9092",
      //key的反序列化类型
      "key.deserializer" -> classOf[StringDeserializer],
      //value的反序列化类型
      "value.deserializer" -> classOf[StringDeserializer],
      //消费发给Kafka需要经过网络传输,而经过网络传输都需要进行序列化,即消息发给kafka需要序列化,那么从kafka消费完就得反序列化
      //消费者组名称
      "group.id" -> "SparkKafka",
      //earliest:当各分区下有已提交的offset时，从提交的offset开始消费；无提交的offset时，从头开始消费
      //latest:当各分区下有已提交的offset时，从提交的offset开始消费；无提交的offset时，消费新产生的该分区下的数据
      //none:当各分区都存在已提交的offset时，从offset后开始消费；只要有一个分区不存在已提交的offset，则抛出异常
      //这里配置latest自动重置偏移量为最新的偏移量,即如果有偏移量从偏移量位置开始消费,没有偏移量从新来的数据开始消费
      "auto.offset.reset" -> "latest",
      //使用手动提交offset
      "enable.auto.commit" -> (false: java.lang.Boolean)
    )
    val topics: Array[String] = Array("covid19_Goods")

    // 从mysql中查询出offsets:Map信息
    val offsetsMap: mutable.Map[TopicPartition, Long] = OffsetUtils.getOffsetsMap("SparkKafka", "covid19_Goods")

    val kafkaDS: InputDStream[ConsumerRecord[String, String]] = if (offsetsMap.nonEmpty) {
      //表示mysql中记录的offset信息，从offset处开始消费
      println("mysql中记录的offset信息，从offset处开始消费")
      // 3.连接kafka获取消息
      KafkaUtils.createDirectStream[String, String](
        ssc,
        LocationStrategies.PreferConsistent,
        ConsumerStrategies.Subscribe[String, String](topics, kafkaParams, offsetsMap))
    } else {
      // 表示mysql中没有记录offset信息，从lastest处开始消费
      println("MySql中没有记录offset信息，从lastest处开始消费")
      // 3.连接kafka获取消息
      KafkaUtils.createDirectStream[String, String](
        ssc,
        LocationStrategies.PreferConsistent,
        ConsumerStrategies.Subscribe[String, String](topics, kafkaParams))
    }

    // 4.实时处理分析数据
    // _表示从kafka中消费出来的每一条消息
    val valueDS: DStream[String] = kafkaDS.map(_.value())
    valueDS.print()
    // {"count":28,"from":"捐赠","name":"84消毒液/瓶"}
    // {"count":23,"from":"采购","name":"防护目镜/副"}
    // {"count":84,"from":"采购","name":"N95口罩/个"}
    // {"count":95,"from":"需求","name":"一次性橡胶手套/副"}
    // {"count":79,"from":"采购","name":"一次性橡胶手套/副"}
    // {"count":73,"from":"消耗","name":"电子体温计/个"}
    // {"count":18,"from":"下拨","name":"84消毒液/瓶"}
    // {"count":61,"from":"需求","name":"N95口罩/个"}
    // {"count":80,"from":"捐赠","name":"84消毒液/瓶"}
    // {"count":66,"from":"下拨","name":"医用防护服/套"}
    //从kafka中消费的数据如以上格式的jsonStr,需要解析为json对象(或者是样例类)
    //目标是:将数据转化成名称,采购,下拨,捐赠,消耗,需求,库存
    //我们需要对每一条的数据进行处理,如接收到一条数据,我们应该(名称,(采购,下拨,捐赠,消耗,需求,库存))
    //4.1 将接收到的数据,转换为需要的元组格式
    val tupleDS: DStream[(String, (Int, Int, Int, Int, Int, Int))] = kafkaDS.map(record => {
      val jsonStr: String = record.value()
      val jsonObj: JSONObject = JSON.parseObject(jsonStr)
      val name: String = jsonObj.getString("name")
      val from: String = jsonObj.getString("from")
      val count: Integer = jsonObj.getInteger("count")
      //根据物质来源的不同，将count记在不同的位置，最终形成同一的格式
      from match {
        //"采购","下拨", "捐赠", "消耗","需求","库存"
        case "采购" => (name, (count, 0, 0, 0, 0, count))
        case "下拨" => (name, (0, count, 0, 0, 0, count))
        case "捐赠" => (name, (0, 0, count, 0, 0, count))
        case "消耗" => (name, (0, 0, 0, -count, 0, -count))
        case "需求" => (name, (0, 0, 0, 0, -count, -count))
      }
    })
    // tupleDS.print()
    // (医用外科口罩/个,(0,0,0,0,-21,-21))
    // (一次性橡胶手套/副,(63,0,0,0,0,63))
    // (医用防护服/套,(0,0,7,0,0,7))
    // (电子体温计/个,(0,0,0,-2,0,-2))
    // (一次性橡胶手套/副,(51,0,0,0,0,51))
    // (医用防护服/套,(62,0,0,0,0,62))
    // (84消毒液/瓶,(0,0,0,0,-40,-40))
    // (医用防护服/套,(0,0,42,0,0,42))
    // (医用外科口罩/个,(0,0,22,0,0,22))
    // (医用防护服/套,(4,0,0,0,0,4))
    // 4.2将上面格式的数据按照key进行一个聚合（有状态的计算）--使用updateStateBykey
    //定义一个函数，用来将当前批次的数据和历史数据进行聚合
    //相同的key回到相同的seq中
    val updateFunc = (currentValues: Seq[(Int, Int, Int, Int, Int, Int)], historyValue: Option[(Int, Int, Int, Int, Int, Int)]) => {
      // 0.定义变量接收当前的数据
      var currentPurchase: Int = 0
      var currentAllocate: Int = 0
      var currentDonate: Int = 0
      var currentConsume: Int = 0
      var currentDemand: Int = 0
      var currentInventory: Int = 0
      // 1.取出当前批次的数据
      if (currentValues.nonEmpty) {
        // 循环当前批次的数据
        for (currentValue <- currentValues) {
          currentPurchase += currentValue._1
          currentAllocate += currentValue._2
          currentDonate += currentValue._3
          currentConsume += currentValue._4
          currentDemand += currentValue._5
          currentInventory += currentValue._6
        }

        // 2.取出历史数据
        val historyPurchase: Int = historyValue.getOrElse((0, 0, 0, 0, 0, 0))._1
        val historyAllocate: Int = historyValue.getOrElse((0, 0, 0, 0, 0, 0))._2
        val historyDonate: Int = historyValue.getOrElse((0, 0, 0, 0, 0, 0))._3
        val historyConsume: Int = historyValue.getOrElse((0, 0, 0, 0, 0, 0))._4
        val historyDemand: Int = historyValue.getOrElse((0, 0, 0, 0, 0, 0))._5
        val historyInventory: Int = historyValue.getOrElse((0, 0, 0, 0, 0, 0))._6
        // 3.将当前批次数据和历史数据进行聚合,4.返回
        Option((
          currentPurchase + historyPurchase,
          currentAllocate + historyAllocate,
          currentDonate + historyDonate,
          currentConsume + historyConsume,
          currentDemand + historyDemand,
          currentInventory + historyInventory
        ))
      } else {
        historyValue
      }

    }
    val resultDS: DStream[(String, (Int, Int, Int, Int, Int, Int))] = tupleDS.updateStateByKey(updateFunc)
    // resultDS.print()

    // 5.将处理分析的结果存入到MySQL
//     CREATE TABLE `covid19_goods` (
//       `name` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
//       `purchase` int(11) DEFAULT NULL,
//       `allocate` int(11) DEFAULT NULL,
//       `donate` int(11) DEFAULT NULL,
//       `consume` int(11) DEFAULT NULL,
//       `demand` int(11) DEFAULT NULL,
//       `inventory` int(11) DEFAULT NULL,
//       PRIMARY KEY (`name`)
//     ) ENGINE=InnoDB DEFAULT CHARSET=utf8;
    resultDS.foreachRDD(rdd => {
      rdd.foreachPartition(lines => {
        // 1.开启连接
        val connection: Connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/covid19?useUnicode=true&characterEncoding=utf-8&serverTimezone=Asia/Shanghai&useSSL=false", "root", "123456")
        // 2.编写sql并获取ps
        val sql: String = "replace into covid19_goods(name,purchase,allocate,donate,consume,demand,inventory) values(?,?,?,?,?,?,?)"
        val ps: PreparedStatement = connection.prepareStatement(sql)
        // 3.设置参数并执行
        try {
          for (row <- lines) {
            ps.setString(1, row._1)
            ps.setInt(2, row._2._1)
            ps.setInt(3, row._2._2)
            ps.setInt(4, row._2._3)
            ps.setInt(5, row._2._4)
            ps.setInt(6, row._2._5)
            ps.setInt(7, row._2._6)
            ps.executeUpdate()
          }
        } finally {
          // 4.关闭资源
          ps.close()
          connection.close()
        }
      })
    })

    // 6.手动提交偏移量
    //我们要手动提交偏移量，那么就意味着，消费了一批数据就应该提交一次偏移量
    //在SparkStreaming中,数据抽象为DStream的底层其实也就是RDD,也就是每一批次的数据
    //所以接下来我们呢应该对DStream中的RDD进行处理
    kafkaDS.foreachRDD(rdd => {
      if (rdd.count() > 0) {
        // 如果该rdd中有数据则处理
        // rdd.foreach(record => println("从kafka中消费到的每一条消息：" + record))
        // 从kafka中消费到的每一条消息：ConsumerRecord(topic = covid19_Goods, partition = 2, offset = 13, CreateTime = 1627369004090, checksum = 992892587, serialized key size = -1, serialized value size = 3, key = null, value = 456)
        // 从kafka中消费到的每一条消息：ConsumerRecord(topic = covid19_Goods, partition = 1, offset = 4, CreateTime = 1627369000238, checksum = 1682005972, serialized key size = -1, serialized value size = 3, key = null, value = 123)
        // 获取偏移量
        // 使用Spark-streaming-kafka-0-10中封装好的API来存放偏移量并提交
        val offsets: Array[OffsetRange] = rdd.asInstanceOf[HasOffsetRanges].offsetRanges
        // for (o <- offsets){
        //   println(s"topic=${o.topic},partition=${o.partition},fromOffset=${o.fromOffset},until=${o.untilOffset}")
        //   // topic=covid19_Goods,partition=1,fromOffset=5,until=6
        //   // topic=covid19_Goods,partition=0,fromOffset=12,until=13
        //   // topic=covid19_Goods,partition=2,fromOffset=14,until=14
        // }
        //手动提交偏移量到kafka的默认主题：__consumer__offsets中，如果开启了Checkpoint，还会提交到Checkpoint中
        // kafkaDS.asInstanceOf[CanCommitOffsets].commitAsync(offsets)
        OffsetUtils.saveOffsets("SparkKafka", offsets)
      }
    })

    // 6.开启SparkStreaming任务并等待结束
    ssc.start()
    ssc.awaitTermination()

  }
}
