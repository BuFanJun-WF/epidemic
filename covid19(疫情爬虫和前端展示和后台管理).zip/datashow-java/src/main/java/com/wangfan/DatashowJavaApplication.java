package com.wangfan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import tk.mybatis.spring.annotation.MapperScan;

/**
 * @author bufanjun
 */
@SpringBootApplication
@MapperScan(basePackages = "com.wangfan.dao")
public class DatashowJavaApplication {

    public static void main(String[] args) {
        SpringApplication.run(DatashowJavaApplication.class, args);
    }

}
