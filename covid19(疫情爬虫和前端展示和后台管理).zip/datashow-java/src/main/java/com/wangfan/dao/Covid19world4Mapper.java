package com.wangfan.dao;

import com.wangfan.domain.Covid19world4;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author bufanjun
 * @date 2021/8/13 0013
 * @Desc
 */
@Repository
public interface Covid19world4Mapper extends Mapper<Covid19world4> {
}
