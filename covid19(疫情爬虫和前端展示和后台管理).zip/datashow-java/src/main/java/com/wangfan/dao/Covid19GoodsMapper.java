package com.wangfan.dao;

import com.wangfan.domain.Covid19Goods;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author bufanjun
 * @date 2021/8/14 0014
 * @Desc
 */
@Repository
public interface Covid19GoodsMapper extends Mapper<Covid19Goods> {
}
