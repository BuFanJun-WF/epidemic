package com.wangfan.dao;

import com.wangfan.domain.Qianru;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author bufanjun
 * @date 2021/8/14 0014
 * @Desc
 */
@Repository
public interface QianruMapper extends Mapper<Qianru> {
}
