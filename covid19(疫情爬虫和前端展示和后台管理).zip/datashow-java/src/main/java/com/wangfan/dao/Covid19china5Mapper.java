package com.wangfan.dao;

import com.wangfan.domain.Covid19china5;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

/**
 * @author bufanjun
 * @date 2021/8/7 0007
 * @Desc
 */
@Repository
public interface Covid19china5Mapper extends Mapper<Covid19china5> {
}
