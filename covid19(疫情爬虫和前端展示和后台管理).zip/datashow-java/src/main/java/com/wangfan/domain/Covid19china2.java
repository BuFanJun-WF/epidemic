package com.wangfan.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author bufanjun
 * @date 2021/8/7 0007
 * @Desc 全国各省累计确诊实体
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "covid19_china2")
public class Covid19china2 implements Serializable {
    private String dateTime;
    @Id
    private Integer locationId;
    private String provinceShortName;
    private Integer currentConfirmedCount;
    private Integer confirmedCount;
    private Integer suspectedCount;
    private Integer curedCount;
    private Integer deadCount;
}
