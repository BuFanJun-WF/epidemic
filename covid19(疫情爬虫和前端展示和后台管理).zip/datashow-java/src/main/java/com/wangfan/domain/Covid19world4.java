package com.wangfan.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author bufanjun
 * @date 2021/8/13 0013
 * @Desc 各大洲的数据
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "covid19_world4")
public class Covid19world4 implements Serializable {
    private String continents;
    private Long currentConfirmedCount;
    private Long confirmedCount;
    private Long suspectedCount;
    private Long curedCount;
    private Long deadCount;
}
