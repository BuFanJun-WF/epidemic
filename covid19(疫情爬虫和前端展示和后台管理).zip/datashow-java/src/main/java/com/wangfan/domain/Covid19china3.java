package com.wangfan.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author bufanjun
 * @date 2021/8/7 0007
 * @Desc 全国疫情趋势实体
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "covid19_china3")
public class Covid19china3 implements Serializable {
    @Id
    private String dateId;
    private Long confirmedIncr;
    private Long confirmedCount;
    private Long suspectedCount;
    private Long curedCount;
    private Long deadCount;
}
