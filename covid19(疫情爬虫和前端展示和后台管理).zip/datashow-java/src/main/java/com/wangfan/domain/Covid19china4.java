package com.wangfan.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author bufanjun
 * @date 2021/8/7 0007
 * @Desc 境外输入实体
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "covid19_china4")
public class Covid19china4 implements Serializable {
    @Id
    private String dateTime;
    private String provinceShortName;
    private Integer pid;
    private Long confirmedCount;
}
