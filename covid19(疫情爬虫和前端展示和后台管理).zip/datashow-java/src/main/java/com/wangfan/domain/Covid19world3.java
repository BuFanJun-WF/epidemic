package com.wangfan.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author bufanjun
 * @date 2021/8/13 0013
 * @Desc 世界疫情数据统计
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "covid19_world3")
public class Covid19world3 implements Serializable {
    private String dateId;
    private Long confirmedIncr;
    private Long confirmedCount;
    private Long suspectedCount;
    private Long curedCount;
    private Long deadCount;
}
