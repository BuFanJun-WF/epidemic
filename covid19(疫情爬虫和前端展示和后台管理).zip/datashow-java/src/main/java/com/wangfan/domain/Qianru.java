package com.wangfan.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author bufanjun
 * @date 2021/8/14 0014
 * @Desc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "qianru")
public class Qianru implements Serializable {
    private String f1;
    private String cityName;
    private String provinceName;
    private String value;
}