package com.wangfan.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;
import java.io.Serializable;

/**
 * @author bufanjun
 * @date 2021/8/13 0013
 * @Desc 国家的疫情数据
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "covid19_world2")
public class Covid19world2 implements Serializable {
    private String dateTime;
    private Long locationId;
    private String provinceName;
    private Long currentConfirmedCount;
    private Long confirmedCount;
    private Long suspectedCount;
    private Long curedCount;
    private Long deadCount;
}
