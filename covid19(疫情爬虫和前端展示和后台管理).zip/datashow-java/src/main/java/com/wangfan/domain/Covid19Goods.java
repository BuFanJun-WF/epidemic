package com.wangfan.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Table;

/**
 * @author bufanjun
 * @date 2021/8/14 0014
 * @Desc
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "covid19_goods")
public class Covid19Goods {
    private String name;
    private Long purchase;
    private Long allocate;
    private Long donate;
    private Long consume;
    private Long demand;
    private Long inventory;
}
