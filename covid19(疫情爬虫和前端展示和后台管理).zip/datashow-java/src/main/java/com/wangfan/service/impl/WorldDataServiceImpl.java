package com.wangfan.service.impl;

import com.wangfan.dao.Covid19world1Mapper;
import com.wangfan.dao.Covid19world2Mapper;
import com.wangfan.dao.Covid19world3Mapper;
import com.wangfan.domain.Covid19world2;
import com.wangfan.domain.Covid19world3;
import com.wangfan.domain.Covid19world1;
import com.wangfan.service.WorldDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.StringUtil;

import java.util.List;
import java.util.Map;

/**
 * @author bufanjun
 * @date 2021/8/13 0013
 * @Desc
 */
@Service
public class WorldDataServiceImpl implements WorldDataService {


    @Autowired
    private Covid19world1Mapper covid19world1Mapper;
    @Autowired
    private Covid19world2Mapper covid19world2Mapper;
    @Autowired
    private Covid19world3Mapper covid19world3Mapper;


    /*------------------对Covid19world1的操作----------------------------------*/
    @Override
    public List<Covid19world1> getWorldDataByDate(Map<String, Object> findMap) {
        Example example = new Example(Covid19world1.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("time"))) {
                criteria.andEqualTo("dateTime", findMap.get("time"));
            }

        }
        return covid19world1Mapper.selectByExample(example);
    }


    /*------------------对Covid19world1的操作----------------------------------*/

    /*------------------对Covid19world2的操作----------------------------------*/
    @Override
    public List<Covid19world2> findAll(Map<String, Object> findMap) {
        Example example = new Example(Covid19world2.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("time"))) {
                criteria.andEqualTo("dateTime", findMap.get("time"));
            }
            example.setOrderByClause("confirmed_count DESC");
        }
        return covid19world2Mapper.selectByExample(example);
    }

    @Override
    public List<Covid19world2> getWorldCuredInTen(Map<String, Object> findMap) {
        Example example = new Example(Covid19world2.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("time"))) {
                criteria.andEqualTo("dateTime", findMap.get("time"));
            }
            example.setOrderByClause("cured_count DESC");
        }
        return covid19world2Mapper.selectByExample(example);
    }

    @Override
    public List<Covid19world2> getWorldDeadInTen(Map<String, Object> findMap) {
        Example example = new Example(Covid19world2.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("time"))) {
                criteria.andEqualTo("dateTime", findMap.get("time"));
            }
            example.setOrderByClause("dead_count DESC");
        }
        return covid19world2Mapper.selectByExample(example);
    }

    @Override
    public List<Covid19world2> getWorldSuspectedInTen(Map<String, Object> findMap) {
        Example example = new Example(Covid19world2.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("time"))) {
                criteria.andEqualTo("dateTime", findMap.get("time"));
            }
            example.setOrderByClause("suspected_count DESC");
        }
        return covid19world2Mapper.selectByExample(example);
    }
    /*------------------对Covid19world2的操作----------------------------------*/

    /*------------------对Covid19world3的操作----------------------------------*/
    @Override
    public List<Covid19world3> fillAllData() {
        return covid19world3Mapper.selectAll();
    }

    @Override
    public List<Covid19world3> getWorldTrend(Map<String, Object> findMap) {
        Example example = new Example(Covid19world3.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("before"))) {
                criteria.andGreaterThanOrEqualTo("dateId", findMap.get("before"));
            }
            if (StringUtil.isNotEmpty((String) findMap.get("today"))) {
                criteria.andLessThanOrEqualTo("dateId", findMap.get("today"));
            }
        }
        return covid19world3Mapper.selectByExample(example);
    }

    
    /*------------------对Covid19world3的操作----------------------------------*/

}
