package com.wangfan.service.impl;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.wangfan.dao.*;
import com.wangfan.domain.*;
import com.wangfan.service.ChinaDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;
import tk.mybatis.mapper.util.StringUtil;

import java.util.List;
import java.util.Map;

/**
 * @author bufanjun
 * @date 2021/8/7 0007
 * @Desc
 */
@Service
public class ChinaDataServiceImpl implements ChinaDataService {

    @Autowired
    private Covid19china1Mapper covid19china1Mapper;

    @Autowired
    private Covid19china2Mapper covid19china2Mapper;

    @Autowired
    private Covid19china3Mapper covid19china3Mapper;

    @Autowired
    private Covid19china4Mapper covid19china4Mapper;

    @Autowired
    private Covid19china5Mapper covid19china5Mapper;

    @Autowired
    private QianruMapper qianruMapper;

    @Autowired
    private Covid19GoodsMapper covid19GoodsMapper;

    /*------------------对Covid19china1的操作----------------------------------*/
    @Override
    public List<Covid19china1> findChinaByDate(Map<String, Object> findMap) {
        Example example = new Example(Covid19china1.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("time"))) {
                criteria.andEqualTo("dateTime", findMap.get("time"));
            }

        }
        return covid19china1Mapper.selectByExample(example);
    }

    @Override
    public Page<Covid19china1> searchChinaData(Map<String, Object> searchMap) {
        //多条件搜索，也就是通用Mapper多条件搜索的标准写法
        //1.初始化分页条件
        int pageNum = 1;
        int pageSize = 15;
        //指定查询的表
        Example example = new Example(Covid19china1.class);
        if (searchMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) searchMap.get("startTime"))) {
                criteria.andGreaterThanOrEqualTo("dateTime", searchMap.get("startTime"));
            }
            if (StringUtil.isNotEmpty((String) searchMap.get("endTime"))) {
                criteria.andLessThanOrEqualTo("dateTime", searchMap.get("endTime"));
            }
            //名称搜索
            if (StringUtil.isNotEmpty((String) searchMap.get("name"))) {
                criteria.andEqualTo("provinceShortName", searchMap.get("name"));
            }
            //分页搜索
            if (StringUtil.isNotEmpty(searchMap.get("pageNum").toString())) {
                pageNum = Integer.parseInt(searchMap.get("pageNum").toString());
            }
            if (StringUtil.isNotEmpty(searchMap.get("pageSize").toString())) {
                pageSize = Integer.parseInt(searchMap.get("pageSize").toString());
            }
            ;

        }
        //使用Pagehelper插件完成分页条件
        PageHelper.startPage(pageNum, pageSize);
        return (Page<Covid19china1>) covid19china1Mapper.selectByExample(example);
    }
    /*------------------对Covid19china1的操作----------------------------------*/

    /*------------------对Covid19china2的操作----------------------------------*/
    @Override
    public List<Covid19china2> findAllProvince() {
        return covid19china2Mapper.selectAll();
    }

    @Override
    public Page<Covid19china2> searchProvince(Map<String, Object> searchMap) {
        //多条件搜索，也就是通用Mapper多条件搜索的标准写法
        //1.初始化分页条件
        int pageNum = 1;
        int pageSize = 15;
        //指定查询的表
        Example example = new Example(Covid19china2.class);
        if (searchMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) searchMap.get("startTime"))) {
                criteria.andGreaterThanOrEqualTo("dateTime", searchMap.get("startTime"));
            }
            if (StringUtil.isNotEmpty((String) searchMap.get("endTime"))) {
                criteria.andLessThanOrEqualTo("dateTime", searchMap.get("endTime"));
            }
            //名称搜索
            if (StringUtil.isNotEmpty((String) searchMap.get("name"))) {
                criteria.andEqualTo("provinceShortName", searchMap.get("name"));
            }
            //分页搜索
            if (StringUtil.isNotEmpty(searchMap.get("pageNum").toString())) {
                pageNum = Integer.parseInt(searchMap.get("pageNum").toString());
            }
            if (StringUtil.isNotEmpty(searchMap.get("pageSize").toString())) {
                pageSize = Integer.parseInt(searchMap.get("pageSize").toString());
            }
            ;

        }
        //使用Pagehelper插件完成分页条件
        PageHelper.startPage(pageNum, pageSize);
        return (Page<Covid19china2>) covid19china2Mapper.selectByExample(example);
    }

    @Override
    public List<Covid19china2> getProvince(Map<String, Object> findMap) {
        Example example = new Example(Covid19china2.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("time"))) {
                criteria.andEqualTo("dateTime", findMap.get("time"));
            }
            if (StringUtil.isNotEmpty((String) findMap.get("id"))) {
                criteria.andLessThanOrEqualTo("locationId", findMap.get("id"));
            }
        }
        return covid19china2Mapper.selectByExample(example);
    }

    @Override
    public List<Covid19china2> showToProvince(Map<String, Object> findMap) {
        Example example = new Example(Covid19china2.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            Example.Criteria criteria1 = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("beforeday"))) {
                criteria.andGreaterThanOrEqualTo("dateTime", findMap.get("beforeday"));
            }
            if (StringUtil.isNotEmpty((String) findMap.get("today"))) {
                criteria.andLessThanOrEqualTo("dateTime", findMap.get("today"));
            }
            //名称搜索
            if (StringUtil.isNotEmpty((String) findMap.get("name1"))) {
                criteria1.orEqualTo("provinceShortName", findMap.get("name1"));
            }
            //名称搜索
            if (StringUtil.isNotEmpty((String) findMap.get("name2"))) {
                criteria1.orEqualTo("provinceShortName", findMap.get("name2"));
            }
            example.and(criteria1);
        }
        return covid19china2Mapper.selectByExample(example);
    }

    /*------------------对Covid19china2的操作----------------------------------*/

    /*------------------对Covid19china3的操作----------------------------------*/
    @Override
    public List<Covid19china3> getCovidInChina() {
        return covid19china3Mapper.selectAll();
    }

    @Override
    public List<Covid19china3> getChinaTrend(Map<String, Object> findMap) {
        Example example = new Example(Covid19china3.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("before"))) {
                criteria.andGreaterThanOrEqualTo("dateId", findMap.get("before"));
            }
            if (StringUtil.isNotEmpty((String) findMap.get("today"))) {
                criteria.andLessThanOrEqualTo("dateId", findMap.get("today"));
            }
        }
        return covid19china3Mapper.selectByExample(example);
    }
    /*------------------对Covid19china3的操作----------------------------------*/

    /*------------------对Covid19china4的操作----------------------------------*/
    @Override
    public List<Covid19china4> findAllImport(Map<String, Object> findMap) {
        Example example = new Example(Covid19china4.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("time"))) {
                criteria.andEqualTo("dateTime", findMap.get("time"));
            }
            example.setOrderByClause("confirmed_count DESC");
        }
        return covid19china4Mapper.selectByExample(example);
    }


    /*------------------对Covid19china4的操作----------------------------------*/

    /*------------------对Covid19china5的操作----------------------------------*/
    @Override
    public List<Covid19china5> getBeijingMapData(Map<String, Object> findMap) {
        Example example = new Example(Covid19china5.class);
        if (findMap != null) {
            //创建查询条件
            Example.Criteria criteria = example.createCriteria();
            //时间区间
            if (StringUtil.isNotEmpty((String) findMap.get("time"))) {
                criteria.andEqualTo("dateTime", findMap.get("time"));
            }

        }
        return covid19china5Mapper.selectByExample(example);
    }

    @Override
    public List<Qianru> findAllQianru(Map<String, Object> findMap) {
        return qianruMapper.selectAll();
    }

    @Override
    public List<Covid19Goods> findAllGoods() {
        return covid19GoodsMapper.selectAll();
    }
    /*------------------对Covid19china5的操作----------------------------------*/
}
