package com.wangfan.service;

import com.wangfan.domain.Covid19world1;
import com.wangfan.domain.Covid19world2;
import com.wangfan.domain.Covid19world3;

import java.util.List;
import java.util.Map;

/**
 * @author bufanjun
 * @date 2021/8/13 0013
 * @Desc
 */
public interface WorldDataService {

    public List<Covid19world3> fillAllData();

    List<Covid19world1> getWorldDataByDate(Map<String, Object> findMap);

    List<Covid19world3> getWorldTrend(Map<String, Object> findMap);

    List<Covid19world2> findAll(Map<String, Object> findMap);

    List<Covid19world2> getWorldCuredInTen(Map<String, Object> findMap);

    List<Covid19world2> getWorldDeadInTen(Map<String, Object> findMap);

    List<Covid19world2> getWorldSuspectedInTen(Map<String, Object> findMap);
}
