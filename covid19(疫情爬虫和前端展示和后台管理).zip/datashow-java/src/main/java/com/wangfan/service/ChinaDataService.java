package com.wangfan.service;

import com.github.pagehelper.Page;
import com.wangfan.domain.*;

import java.util.List;
import java.util.Map;

/**
 * @author bufanjun
 * @date 2021/8/7 0007
 * @Desc 中国数据服务层
 */
public interface ChinaDataService {

    List<Covid19china1> findChinaByDate(Map<String, Object> findMap);

    Page<Covid19china1> searchChinaData(Map<String, Object> searchMap);

    List<Covid19china2> findAllProvince();

    Page<Covid19china2> searchProvince(Map<String, Object> searchMap);

    List<Covid19china2> getProvince(Map<String, Object> findMap);


    List<Covid19china3> getCovidInChina();

    List<Covid19china3> getChinaTrend(Map<String, Object> findMap);

    List<Covid19china4> findAllImport(Map<String, Object> findMap);

    List<Covid19china2> showToProvince(Map<String, Object> findMap);

    List<Covid19china5> getBeijingMapData(Map<String, Object> findMap);

    List<Qianru> findAllQianru(Map<String, Object> findMap);

    List<Covid19Goods> findAllGoods();
}
