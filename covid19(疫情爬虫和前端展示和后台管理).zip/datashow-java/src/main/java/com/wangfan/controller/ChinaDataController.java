package com.wangfan.controller;

import com.github.pagehelper.Page;
import com.wangfan.common.PageResult;
import com.wangfan.common.Result;
import com.wangfan.domain.*;
import com.wangfan.service.ChinaDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author bufanjun
 * @date 2021/8/7 0007
 * @Desc 对中国的数据进行处理的
 */

@RestController
@RequestMapping("China")
public class ChinaDataController {

    @Autowired
    private ChinaDataService chinaDataService;

    /*------------------对Covid19china1的操作----------------------------------*/
    //提供一个具体的日期进行查询，中国的当天的数据
    @RequestMapping("/getChinaDataByDate")
    public Result getChinaDataByDate(@RequestBody Map<String,Object> findMap){
        List<Covid19china1> getData = chinaDataService.findChinaByDate(findMap);
        return Result.succ(getData.get(0));
    }
    //对中国的数据进行分页出来
    @RequestMapping("searchChinaData")
    public PageResult searchChinaData(@RequestBody Map<String,Object> searchMap){
        Page<Covid19china1> pageChinaData = chinaDataService.searchChinaData(searchMap);
        return PageResult.succ(pageChinaData.getResult(),pageChinaData.getTotal());
    }
    /*------------------对Covid19china1的操作----------------------------------*/

    /*------------------对Covid19china2的操作----------------------------------*/
    //查找全国所有省份的数据
    @RequestMapping("/findAllProvince")
    public Result findAllProvince(){
        List<Covid19china2> allProvince = chinaDataService.findAllProvince();
        return Result.succ(allProvince);
    }
    //通过多条件查询全国所有省份的数据
    @RequestMapping("/searchProvince")
    public PageResult searchProvince(@RequestBody Map<String,Object> searchMap){
        Page<Covid19china2> pageProvince = chinaDataService.searchProvince(searchMap);
        return PageResult.succ(pageProvince.getResult(),pageProvince.getTotal());
    }
    //通过时间和id进行准确查找省份的数据
    @RequestMapping("/getProvince")
    public Result getProvince(@RequestBody Map<String,Object> findMap){
        List<Covid19china2> province  = chinaDataService.getProvince(findMap);
       return Result.succ(province.get(0));
    }
    //通过时间和id进行准确查找省份的数据
    @RequestMapping("/getProvinces")
    public Result getProvinces(@RequestBody Map<String,Object> findMap){
        List<Covid19china2> provinces  = chinaDataService.getProvince(findMap);
        return Result.succ(provinces);
    }
    //通过时间范围和名称进行查询数据
    @RequestMapping("/showToProvince")
    public Result showToProvince(@RequestBody Map<String,Object> findMap){
        List<Covid19china2> provinces  = chinaDataService.showToProvince(findMap);
        return Result.succ(provinces);
    }

    //通过时间进行准确查找当天省份的数据，返回省份名和确诊数据
    @RequestMapping("/getChinaMapData")
    public Result getChinaMapData(@RequestBody Map<String,Object> findMap){
        List<Covid19china2> provinces  = chinaDataService.getProvince(findMap);
        List<Map<String, Object>> provinceList = new ArrayList<Map<String, Object>>();
        for (Covid19china2 province:
             provinces) {
            String provinceShortName = province.getProvinceShortName();
            Integer confirmedCount = province.getConfirmedCount();
            Map<String, Object> map = new HashMap<>();
            map.put("name",provinceShortName);
            map.put("value",confirmedCount);
            provinceList.add(map);
        }
        return Result.succ(provinceList);
    }
    /*------------------对Covid19china2的操作----------------------------------*/


    /*------------------对Covid19china3的操作----------------------------------*/
    @RequestMapping("/getCovidInChina")
    public Result getCovidInChina(){
        List<Covid19china3> covidInChina = chinaDataService.getCovidInChina();
        return Result.succ(covidInChina);
    }

    //获取中国疫情趋势
    @RequestMapping("/getChinaTrend")
    public Result getChinaTrend(@RequestBody Map<String,Object> findMap){
        List<Covid19china3> covid19china3s = chinaDataService.getChinaTrend(findMap);
        List<Map<String, Object>> chinaTrend = new ArrayList<Map<String, Object>>();
        for (int i=covid19china3s.size(); i>1; i--){
            Covid19china3 covid19china3 = covid19china3s.get(i - 1);
            Covid19china3 covid19china3next = covid19china3s.get(i - 2);
            long suspectedCountIncr = covid19china3.getSuspectedCount() - covid19china3next.getSuspectedCount();
            long curedCountIncr = covid19china3.getCuredCount() - covid19china3next.getCuredCount();
            long deadCountIncr = covid19china3.getDeadCount() - covid19china3next.getDeadCount();
            Map<String, Object> map = new HashMap<>();
            map.put("dateId",covid19china3.getDateId());
            map.put("suspectedCountIncr",suspectedCountIncr);
            map.put("curedCountIncr",curedCountIncr);
            map.put("deadCountIncr",deadCountIncr);
            map.put("confirmedIncr",covid19china3.getConfirmedIncr());
            chinaTrend.add(map);
        }

        return Result.succ(chinaTrend);
    }


    /*------------------对Covid19china3的操作----------------------------------*/

    /*------------------对Covid19china4的操作----------------------------------*/
    @RequestMapping("/getImportChinaInFive")
    public Result getImportChinaInFive(@RequestBody Map<String,Object> findMap) {
        List<Covid19china4> covid19china4s = chinaDataService.findAllImport(findMap);
        List<Covid19china4> provinceInFive = new ArrayList<Covid19china4>();
        for (int i=0; i<5; i++){
            provinceInFive.add(covid19china4s.get(i));
        }
        return Result.succ(provinceInFive);
    }
    /*------------------对Covid19china4的操作----------------------------------*/

    /*------------------对Covid19china5的操作----------------------------------*/
    @RequestMapping("/getBeijingMapData")
    public Result getBeijingMapData(@RequestBody Map<String,Object> findMap){
        List<Covid19china5> cities  = chinaDataService.getBeijingMapData(findMap);
        List<Map<String, Object>> cityList = new ArrayList<Map<String, Object>>();
        for (Covid19china5 city:
                cities) {
            String cityName = city.getCityName();
            Integer confirmedCount = city.getConfirmedCount();
            Map<String, Object> map = new HashMap<>();
            map.put("name",cityName);
            map.put("value",confirmedCount);
            cityList.add(map);
        }
        return Result.succ(cityList);
    }

    /*------------------对Covid19china5的操作----------------------------------*/

    @RequestMapping("/Population")
    public Result getPopulation(@RequestBody Map<String,Object> findMap) {
        List<Qianru> qianrus = chinaDataService.findAllQianru(findMap);
        List<Map<String,Object>> provinceInTen = new ArrayList<Map<String,Object>>();
        for (int i=0; i<10; i++){
            HashMap<String, Object> map = new HashMap<>();
            String name = qianrus.get(i).getProvinceName()+qianrus.get(i).getCityName();
            Double value = Double.valueOf(qianrus.get(i).getValue());
            map.put("provinceName",name);
            map.put("confirmedCount",value);

            provinceInTen.add(map);
        }
        return Result.succ(provinceInTen);
    }

    @RequestMapping("/getGoods")
    public Result getGoods(){
        List<Covid19Goods> goods = chinaDataService.findAllGoods();
        return Result.succ(goods);
    }
}
