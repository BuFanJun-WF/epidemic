package com.wangfan.controller;

import com.wangfan.common.Result;
import com.wangfan.domain.*;
import com.wangfan.domain.Covid19world1;
import com.wangfan.domain.Covid19world3;
import com.wangfan.service.WorldDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author bufanjun
 * @date 2021/8/13 0013
 * @Desc
 */
@RestController
@RequestMapping("World")
public class WorldDataController {

    @Autowired
    public WorldDataService worldDataService;

    /*------------------对Covid19world1的操作----------------------------------*/
    @RequestMapping("/getWorldDataByDate")
    public Result getWorldDataByDate(@RequestBody Map<String,Object> findMap){
        List<Covid19world1> getData = worldDataService.getWorldDataByDate(findMap);
        return Result.succ(getData.get(0));
    }
    /*------------------对Covid19world1的操作----------------------------------*/

    /*------------------对Covid19world2的操作----------------------------------*/
    @RequestMapping("/getWorldInTen")
    public Result getImportWorldInFive(@RequestBody Map<String,Object> findMap) {
        List<Covid19world2> covid19world4s = worldDataService.findAll(findMap);
        List<Covid19world2> provinceInTen = new ArrayList<Covid19world2>();
        for (int i=0; i<10; i++){
            provinceInTen.add(covid19world4s.get(i));
        }
        return Result.succ(provinceInTen);
    }
    @RequestMapping("/getWorldCuredInTen")
    public Result getWorldCuredInTen(@RequestBody Map<String,Object> findMap) {
        List<Covid19world2> covid19world4s = worldDataService.getWorldCuredInTen(findMap);
        List<Covid19world2> provinceInTen = new ArrayList<Covid19world2>();
        for (int i=0; i<10; i++){
            provinceInTen.add(covid19world4s.get(i));
        }
        return Result.succ(provinceInTen);
    }

    @RequestMapping("/getWorldDeadInTen")
    public Result getWorldDeadInTen(@RequestBody Map<String,Object> findMap) {
        List<Covid19world2> covid19world4s = worldDataService.getWorldDeadInTen(findMap);
        List<Covid19world2> provinceInTen = new ArrayList<Covid19world2>();
        for (int i=0; i<10; i++){
            provinceInTen.add(covid19world4s.get(i));
        }
        return Result.succ(provinceInTen);
    }
    @RequestMapping("/getWorldSuspectedInTen")
    public Result getWorldSuspectedInTen(@RequestBody Map<String,Object> findMap) {
        List<Covid19world2> covid19world4s = worldDataService.getWorldSuspectedInTen(findMap);
        List<Covid19world2> provinceInTen = new ArrayList<Covid19world2>();
        for (int i=0; i<10; i++){
            provinceInTen.add(covid19world4s.get(i));
        }
        return Result.succ(provinceInTen);
    }
    /*------------------对Covid19world2的操作----------------------------------*/


    /*------------------对Covid19world3的操作----------------------------------*/
    @RequestMapping("/fillAllData")
    public Result fillAllData(){
        List<Covid19world3> covid19world3s = worldDataService.fillAllData();
        return Result.succ(covid19world3s);
    }

    //获取世界疫情趋势
    @RequestMapping("/getWorldTrend")
    public Result getWorldTrend(@RequestBody Map<String,Object> findMap){
        List<Covid19world3> covid19world3s = worldDataService.getWorldTrend(findMap);
        List<Map<String, Object>> worldTrend = new ArrayList<Map<String, Object>>();
        for (int i=covid19world3s.size(); i>1; i--){
            Covid19world3 covid19world3 = covid19world3s.get(i - 1);
            Covid19world3 covid19world3next = covid19world3s.get(i - 2);
            long suspectedCountIncr = covid19world3.getSuspectedCount() - covid19world3next.getSuspectedCount();
            long curedCountIncr = covid19world3.getCuredCount() - covid19world3next.getCuredCount();
            long deadCountIncr = covid19world3.getDeadCount() - covid19world3next.getDeadCount();
            Map<String, Object> map = new HashMap<>();
            map.put("dateId",covid19world3.getDateId());
            map.put("suspectedCountIncr",suspectedCountIncr);
            map.put("curedCountIncr",curedCountIncr);
            map.put("deadCountIncr",deadCountIncr);
            map.put("confirmedIncr",covid19world3.getConfirmedIncr());
            worldTrend.add(map);
        }

        return Result.succ(worldTrend);
    }
    /*------------------对Covid19world3的操作----------------------------------*/

    /*------------------对Covid19world4的操作----------------------------------*/
    /*------------------对Covid19world4的操作----------------------------------*/
}
