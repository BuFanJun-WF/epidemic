package com.wangfan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatashowJavaApplicationTests {

    @Test
    void contextLoads() {
    }

}
