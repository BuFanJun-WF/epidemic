<template>
  <div class="dashboard-editor-container">
    <el-row>
      <el-col :span="6">
        <el-card style="width: 200px">
          <div style="height: 200px; width: 150px"><img :src="src1" class="image"></div>

          <div style="padding: 10px; padding-left:20px">
            <span>用户数:   {{ userNum }}</span>
          </div>
        </el-card>


      </el-col>

      <el-col :span="6">
        <el-card style="width: 200px">
          <div style="height: 200px; width: 150px"><img :src="src2" class="image"></div>

          <div style="padding: 10px; padding-left:20px">
            <span>医用口罩储备:   {{ maskNum }}</span>
          </div>
        </el-card>


      </el-col>

      <el-col :span="6">
        <el-card style="width: 200px">
          <div style="height: 200px; width: 150px"><img :src="N95Mask" class="image"></div>

          <div style="padding: 10px; padding-left:20px">
            <span>N95口罩储备:   {{ mask2Num }}</span>
          </div>
        </el-card>


      </el-col>

      <el-col :span="6">
        <el-card style="width: 200px">
          <div style="height: 200px; width: 150px"><img :src="gloves" class="image"></div>

          <div style="padding: 10px; padding-left:20px">
            <span>一次性手套储备:   {{ glovesNum }}</span>
          </div>
        </el-card>


      </el-col>

    </el-row>

    <el-row style="padding-top: 20px">
      <el-col :span="6">
        <el-card style="width: 200px">
          <div style="height: 200px; width: 150px"><img :src="glasses" class="image"></div>

          <div style="padding: 10px; padding-left:20px">
            <span>护目镜储备:   {{ glassesNum }}</span>
          </div>
        </el-card>


      </el-col>

      <el-col :span="6">
        <el-card style="width: 200px">
          <div style="height: 200px; width: 150px"><img :src="cloth" class="image"></div>

          <div style="padding: 10px; padding-left:20px">
            <span>防护服储备:   {{ clothNum }}</span>
          </div>
        </el-card>


      </el-col>

      <el-col :span="6">
        <el-card style="width: 200px">
          <div style="height: 200px; width: 150px"><img :src="l84" class="image"></div>

          <div style="padding: 10px; padding-left:20px">
            <span>84消毒液储备:   {{ lNum }}</span>
          </div>
        </el-card>


      </el-col>

      <el-col :span="6">
        <el-card style="width: 200px">
          <div style="height: 200px; width: 150px"><img :src="ther" class="image"></div>

          <div style="padding: 10px; padding-left:20px">
            <span>电子体温计储备:   {{ therNum }}</span>
          </div>
        </el-card>


      </el-col>

    </el-row>
  </div>
</template>

<script>
import user from '@/assets/user.png'
import good from '@/assets/mask.png'
import l84 from '@/assets/84.jpg'
import gloves from '@/assets/gloves.png'
import N95Mask from '@/assets/N95Mask.png'
import cloth from '@/assets/cloth.png'
import ther from '@/assets/ther.png'
import glasses from '@/assets/glasses.png'

export default {

  name: "Index",
  data() {
    return {
      userNum: 0,
      maskNum: 0,
      mask2Num: 0,
      lNum: 0,
      glovesNum: 0,
      clothNum: 0,
      therNum: 0,
      glassesNum: 0,
      l84: l84,
      gloves: gloves,
      src1: user,
      src2: good,
      N95Mask: N95Mask,
      cloth: cloth,
      ther: ther,
      glasses: glasses
    }
  },
  created() {
    this.getNum();

  },
  methods: {
    getNum() {
      this.$axios.get("/getNum")
          .then(res => {

            this.userNum = res.data.data.userNum
            this.maskNum = res.data.data.maskNum
            this.mask2Num = res.data.data.mask2Num
            this.glovesNum = res.data.data.glovesNum
            this.glassesNum = res.data.data.glassesNum
            this.clothNum = res.data.data.clothNum
            this.therNum = res.data.data.therNum
            this.lNum = res.data.data.lNum
            console.log(res.data.data.clothNum + "----------???????????" )
          })

    }
  }
}
</script>


<style>
.image {
  width: 150px;
  display: block;
}

.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
}
</style>