
<template>
  <body id="poster">
  <el-form :model="ruleForm" status-icon :rules="rules" ref="ruleForm" class="login-container" label-position="left"
           label-width="0px">
    <h3 class="login_title">用户注册</h3>
    <el-form-item  prop="username">
      <el-input v-model="ruleForm.username" placeholder="用户名"></el-input>
    </el-form-item>
    <el-form-item prop="pass">
      <el-input type="password" v-model="ruleForm.pass" autocomplete="off" placeholder="密码"></el-input>
    </el-form-item>
    <el-form-item  prop="checkPass">
      <el-input type="password" v-model="ruleForm.checkPass" autocomplete="off" placeholder="确认密码"></el-input>
    </el-form-item>
    <el-form-item  prop="email">
      <el-input v-model="ruleForm.email" placeholder="邮箱"></el-input>
    </el-form-item>
    <el-form-item>
      <el-button style="margin-left: 40px" type="primary" v-on:click="toRegister">提交</el-button>
      <el-button style="margin-left: 100px" @click="resetForm('ruleForm')">重置</el-button>
    </el-form-item>
  </el-form>
  </body>
</template>

<script>
export default {
  data() {
    var checkUserName = (rule, value, callback) => {
      if (!value) {

        return callback(new Error('用户名不能为空'));
      }else {
        // this.$axios
        //     .post('/check',{
        //       username: value
        //     })
        //     .then(successResponse => {
        //     }).catch(()=>{
        //   return callback(new Error('用户名不能重复'))
        // })
      }
    };

    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'));
      } else {
        if (this.ruleForm.checkPass !== '') {
          this.$refs.ruleForm.validateField('checkPass');
        }
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'));
      } else if (value !== this.ruleForm.pass) {
        callback(new Error('两次输入密码不一致!'));
      } else {
        callback();
      }
    };
    var checkEmail = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('邮箱不能为空'));
      }
      var myReg=/^[a-zA-Z0-9_-]+@([a-zA-Z0-9]+\.)+(com|cn|net|org)$/;
      if(!myReg.test(value)){
        return callback(new Error('邮箱格式错误'));
      }

    };
    return {
      ruleForm: {
        pass: '',
        checkPass: '',
        username: '',
        email: ''
      },
      rules: {
        pass: [
          { validator: validatePass, trigger: 'blur' }
        ],
        checkPass: [
          { validator: validatePass2, trigger: 'blur' }
        ],
        username: [
          { validator: checkUserName, trigger: 'blur' }
        ],
        email: [
          { validator: checkEmail, trigger: 'blur' }
        ]

      }
    };
  },
  methods: {
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    toRegister(){
      this.$axios
          .post('/register',{
            username: this.ruleForm.username,
            password: this.ruleForm.pass,
            email: this.ruleForm.email
          })
          .then(res => {
            this.$router.push("/login")
          })
    }


  }
}
</script>

<style>
#poster {
  background-image: url("../assets/login_bp.png");
  background-position: center;
  height: 100%;
  width: 100%;
  background-size: cover;
  position: fixed;
}
body{
  margin: 0px;
}
.login-container {
  border-radius: 15px;
  background-clip: padding-box;
  margin: 90px auto;
  width: 350px;
  padding: 35px 35px 15px 35px;
  background: #fff;
  border: 1px solid #eaeaea;
  box-shadow: 0 0 25px #cac6c6;
}
.login_title {
  margin: 0px auto 40px auto;
  text-align: center;
  color: #505458;
}
</style>
