<template>
  <el-row :gutter="20" class="row-bg">
    <el-col :xl="6" :lg="7" :offset="5">
      <div class="grid-content bg-purple">
        <h2>疫情防控数据管理系统</h2>
        <el-form :model="loginForm" :rules="rules"  ref="loginForm"  class="demo-loginForm">
          <el-form-item label="用户名" prop="username" style="width: 380px;">
            <el-input v-model="loginForm.username"></el-input>
          </el-form-item>
          <el-form-item label="密码" prop="password" style="width: 380px;">
            <el-input type="password" v-model="loginForm.password"></el-input>
          </el-form-item>
          <el-form-item label="验证码" prop="code" style="width: 380px;">
            <el-input v-model="loginForm.code" style="width: 172px; float: left;"></el-input>
            <el-image :src="captchaImg" class="captchaImg" style="float: right" @click="getCaptcha"></el-image>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('loginForm')">立即登录</el-button>
            <el-button @click="resetForm('loginForm')">重置</el-button>
            <el-button @click="toRegister">注册</el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-col>
  </el-row>

</template>

<script>
//axios默认的content-type是application/json
//使用的qs进行序列化
// 那么content-type就是application/x-www-form-urlencoded也就是常说的表单提交
import qs from 'qs'

export default {
  name: "Login",
  data() {
    return {
      loginForm: {
        username: '',
        password: '',
        code: '',
        token: ''
      },
      rules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
        ],
        password: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 3, max: 20, message: '长度在 3 到 20 个字符', trigger: 'blur' }
        ],
        code: [
          { required: true, message: '请输入验证码', trigger: 'blur' },
          { min: 5, max: 5, message: '长度为 5 个字符', trigger: 'blur' }
        ],
      },
      captchaImg: null
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$axios.post('/login?'+ qs.stringify(this.loginForm)).then(res => {

            console.log(res)

            const jwt = res.headers['authorization']

            this.$store.commit('SET_TOKEN', jwt)
            this.$router.push("/index")
          })

        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    getCaptcha() {
      this.$axios.get('/captcha').then(res => {

        console.log("/captcha")
        console.log(res.code)

        this.loginForm.token = res.data.data.token
        this.captchaImg = res.data.data.captchaImg
        this.loginForm.code = ''
      })
    },
    toRegister() {

      this.$router.push({path: '/register'})
    }
  },
  //在页面创建的时候就开始执行执行
  created() {
    this.getCaptcha()
  }
}
</script>

<style scoped>

.el-row {
  background-image: url("../assets/login_bp.png");
  height: 100%;
  display: flex;
  align-items: center;
  text-align: center;
  width: 100%;
  background-size: cover;
  background-position: center;
  position: relative;
}

.el-col {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  background-color: #fafafa;
  border-radius: 4px;
  opacity: 90%;
}

.el-divider {
  height: 200px;
}

.captchaImg {
  float: left;
  margin-left: 8px;
  border-radius: 4px;
}

</style>