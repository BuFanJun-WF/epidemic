<template>
<div >
  <div>
    <el-input v-model="listQuery.name" style="width: 190px; " placeholder="请输入物资名" />
    <el-button  type="primary" icon="el-icon-search" style="margin-left: 20px" @click="handleFind">查找</el-button>
    <el-button type="primary" icon="el-icon-edit" style="margin-left: 20px" @click="handleCreate">添加</el-button>
  </div>

  <el-table
      v-loading="listLoading"
      element-loading-text="正在查询中。。。"
      :data="tableData"
      border
      style="width: 100%; margin-top: 20px" >
    <el-table-column
        prop="name"
        label="物资">
    </el-table-column>
    <el-table-column
        prop="purchase"
        label="购买数">
    </el-table-column>
    <el-table-column
      prop="allocate"
      label="调配数">
  </el-table-column>
    <el-table-column
        prop="donate"
        label="捐赠数">
    </el-table-column>
    <el-table-column
        prop="consume"
        label="已消耗">
    </el-table-column>
    <el-table-column
        prop="demand"
        label="总需求">
    </el-table-column>
    <el-table-column
        prop="inventory"
        label="库存">
    </el-table-column>
    <el-table-column align="center" label="操作" width="200" class-name="small-padding fixed-width">
      <template slot-scope="scope">
        <el-button  type="primary" size="mini" @click="handleUpdate(scope.row)">编辑</el-button>
        <el-button  type="danger" size="mini" @click="handleDelete(scope.row)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>

  <el-dialog :title="textMap[dialogStatus]" :visible.sync="dialogFormVisible">
    <el-form ref="dataForm" :rules="rules" :model="formdata" status-icon label-position="left" label-width="100px" style="width: 400px; margin-left:50px;">
      <el-form-item label="物资" prop="name" v-if="dialogStatus=='create'" >
        <el-input v-model="formdata.name" />
      </el-form-item>
      <el-form-item label="购买数" prop="purchase">
        <el-input v-model="formdata.purchase" />
      </el-form-item>
      <el-form-item label="调配数" prop="allocate">
        <el-input v-model="formdata.allocate" />
      </el-form-item>
      <el-form-item label="捐赠数" prop="donate">
      <el-input v-model="formdata.donate" />
    </el-form-item>
      <el-form-item label="已消耗" prop="consume">
        <el-input v-model="formdata.consume" />
      </el-form-item>
      <el-form-item label="总需求" prop="demand">
        <el-input v-model="formdata.demand" />
      </el-form-item>
    </el-form>

    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">取消</el-button>
      <el-button v-if="dialogStatus=='create'" type="primary" @click="createData">确定</el-button>
      <el-button v-else type="primary" @click="updateData">确定</el-button>
    </div>
  </el-dialog>
</div>

</template>

<script>
import SideMenu from "../inc/SideMenu";
import Tabs from "../inc/Tabs";
import Element from "element-ui";
export default {
  name: "List",
  components: {SideMenu},
  data() {
    return {
      dialogStatus: undefined,
      textMap:{
        update: '编辑',
        create: '创建'
      },
      tableData: [],
      listQuery: {
        id:undefined,
        name:undefined,
        purchase:undefined,
        allocate : undefined,
        donate : undefined,
        consume : undefined,
        demand: undefined,
        inventory: undefined
      },
      formdata: {

        name:undefined,
        purchase:undefined,
        allocate : undefined,
        donate : undefined,
        consume : undefined,
        demand: undefined,
        inventory: undefined
      },
      listLoading: true,
      dialogFormVisible:false,
      rules: {
        name: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        purchase: [
          { required: true, message: '不能为空', trigger: 'blur' }
        ],
        allocate: [{ required: true, message: '不能为空', trigger: 'blur' }],
        donate: [{ required: true, message: '不能为空', trigger: 'blur' }],
        consume: [{ required: true, message: '不能为空', trigger: 'blur' }],
        demand: [{ required: true, message: '不能为空', trigger: 'blur' }],
        inventory: [{ required: true, message: '不能为空', trigger: 'blur' }],
      },
    }
  },
  created() {
    this.getList()
  },

  methods:{
     getList(){
       this.listLoading = true
       this.$axios.get('/goods/list',{
         params:{
           name: this.listQuery.name
         }
       }).
       then(response => {
         console.log(response.data.data)
          this.tableData = response.data.data
         this.listLoading = false
       }).catch(()=>{
         console.log("error")
         this.tableData = []
         this.listLoading = false;
       })
     },
    handleCreate(){
      this.formdata.name = undefined
      this.formdata.demand = undefined
      this.formdata.consume = undefined
      this.formdata.inventory = undefined
      this.formdata.allocate =undefined
      this.formdata.donate = undefined
      this.formdata.purchase =undefined
      this.dialogStatus = 'create'
      this.dialogFormVisible = true
      this.$nextTick(() => {
        this.$refs['formdata'].clearValidate()
      })
    },
  handleUpdate(row) {
    this.formdata = Object.assign({}, row)
    this.dialogStatus = 'update'
    this.dialogFormVisible = true
    this.$nextTick(() => {
      this.$refs['formdata'].clearValidate()
    })
  },
    handleDelete(row){
      this.$axios.get("/goods/delete",{
        params:{
          name:row.name
        }
      }).then(res =>{
        this.getList()
      })

    },
    createData(){


        this.$axios.post("/goods/add",{
          name:this.formdata.name,
          purchase:this.formdata.purchase,
          allocate:this.formdata.allocate,
          demand : this.formdata.demand,
          consume:this.formdata.consume,
          donate:this.formdata.donate,
          inventory: parseInt(
              this.formdata.purchase,10)  +
              parseInt(this.formdata.donate,10)   +
              parseInt(this.formdata.allocate,10)  +
              parseInt(this.formdata.consume,10)  +
              parseInt(this.formdata.demand,10)

        }).then(res =>{
          this.dialogFormVisible = false
          this.dialogFormVisible = false
          this.formdata.name = undefined
          this.formdata.demand = undefined
          this.formdata.consume = undefined
          this.formdata.inventory = undefined
          this.formdata.allocate =undefined
          this.formdata.donate = undefined
          this.formdata.purchase =undefined
          this.getList()
        })
      this.getList()
    },
  updateData() {
    this.$axios.post("/goods/update",{
      name:this.formdata.name,
      purchase:this.formdata.purchase,
      allocate:this.formdata.allocate,
      demand : this.formdata.demand,
      consume:this.formdata.consume,
      donate:this.formdata.donate,
      inventory: parseInt(
          this.formdata.purchase,10)  +
          parseInt(this.formdata.donate,10)   +
          parseInt(this.formdata.allocate,10)  +
          parseInt(this.formdata.consume,10)  +
          parseInt(this.formdata.demand,10)

    }).then(res =>{
      this.dialogFormVisible = false
      this.formdata.name = undefined
      this.formdata.demand = undefined
      this.formdata.consume = undefined
      this.formdata.inventory = undefined
      this.formdata.allocate =undefined
      this.formdata.donate = undefined
      this.formdata.purchase =undefined
      this.getList()
    })
    this.getList()

  },
    handleFind(){

       this.getList()
    },
    checkNum(){
       console.log(this.formdata.name)
       if(parseInt(
           this.formdata.purchase,10)  +
           parseInt(this.formdata.donate,10)   +
       parseInt(this.formdata.allocate,10)  +
       parseInt(this.formdata.consume,10)  +
       parseInt(this.formdata.demand,10)  !==  parseInt(this.formdata.inventory,10) ){
         Element.Message.error('数据有误', {duration: 3000})
         return true
       }
       return  false
    }


  }
}

</script>

<style scoped>

</style>