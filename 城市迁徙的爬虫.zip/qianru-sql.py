import json
import os
import json
import time
import pymysql
import requests
import re
import pandas as pd
# http://huiyan.baidu.com/migration/cityrank.jsonp?dt=city&id=440100&type=move_in&callback=jsonp_1628670127203_8397230
url='http://huiyan.baidu.com/migration/cityrank.jsonp?dt=city&id=440100&type=move_in&callback=jsonp_%d'%int(time.time()*1000)
a=time.time()*1000
def getPageInfo():
    response=requests.get(url=url).text
    # response.encoding='utf-8'
    response=response.strip()
    response=response.strip('jsonp_%d('%a)
    response=response.strip(')')
    file=os.getcwd()+'/qianru.json'  #获得当前路径+文件名
    output=open(file,'a',encoding='utf-8')  #以追加的方式打开一个文件
    output.write(response)  #写入内容
    output.close()

def get_data():
    with open('./qianru.json', 'r') as f:
        data = json.load(f)  # 解析每一行数据
    return data

def data_insert(data):
    qianxi_data=data['data']['list']
    data_set=[]
    for i in qianxi_data:
        data_dict={}
        data_dict['city_name']=i['city_name']
        data_dict['province_name']=i['province_name']
        data_dict['value']=i['value']
        data_set.append(data_dict)
    df=pd.DataFrame(data_set)
    df.to_csv(r'./qianru.csv')

if __name__ == "__main__":  # 起到一个初始化或者调用函数的作用
    getPageInfo()
    a = get_data()
    data_insert(a)
